--
-- FastNightGui
-- V1.0.0.0
--
-- @author apuehri
-- @date 09/12/2018
--
-- Copyright (C) apuehri

StockmanGui = {};

local stockmanGui_mt = Class(StockmanGui, ScreenElement);

function StockmanGui:new(target, custom_mt)
    local self = ScreenElement:new(target, stockmanGui_mt);
    self.returnScreenName = "";
    return self;	
end;

function StockmanGui:onOpen()
    StockmanGui:superClass().onOpen(self);
	FocusManager:setFocus(self.backButton);
end;

function StockmanGui:onClose()
    StockmanGui:superClass().onClose(self);
end;

function StockmanGui:onClickBack(t, okClicked)
    StockmanGui:superClass().onClickBack(self);
	self:callback(okClicked or false)
end;

function StockmanGui:onClickOk()
    StockmanGui:superClass().onClickOk(self);
	-- fastnight:settingsFromGui(self.sdh:getState(), self.sdm:getState(), self.dts:getState(), self.adts:getIsChecked(), self.snh:getState(), self.snm:getState(), self.nts:getState(), self.ants:getIsChecked(), self.shhe:getIsChecked());
    self:onClickBack(self, true);
    -- self:callback(false)
    
end;

function StockmanGui:onIngameMenuHelpTextChanged(element)
end;

function StockmanGui:onCreateFnGuiHeader(element)
	element.text = g_i18n:getText('gui_fn_Setting');
end;

function StockmanGui:onCreateStartDayHour(element)
    -- self.sdh = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_StartDayHour');
	-- element.toolTipText = g_i18n:getText('gui_fn_StartDayHourToolTip');
    -- local hour = {};

    -- for i = 1, #fastnight.hourSteps, 1 do
    --     hour[i] = ""..tostring(fastnight.hourSteps[i]).. " h";
    -- end;
    -- element:setTexts(hour);
end;

function StockmanGui:onCreateStartDayMinute(element)
    -- self.sdm = element;
    -- element.labelElement.text = g_i18n:getText('gui_fn_StartDayMinute');
	-- element.toolTipText = g_i18n:getText('gui_fn_StartDayMinuteToolTip');
	-- local minute = {};

    -- for i = 1, #fastnight.minuteSteps, 1 do
    --     minute[i] = ""..tostring(fastnight.minuteSteps[i]).. " m";
    -- end;
    -- element:setTexts(minute);
end;

function StockmanGui:onCreateDayTimeScale(element)
    -- self.dts = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_DayTimeScale');
	-- element.toolTipText = g_i18n:getText('gui_fn_DayTimeScaleToolTip');
    -- local timeScale = {};

    -- for i = 1, #fastnight.timeScaling, 1 do
    --     timeScale[i] = ""..tostring(fastnight.timeScaling[i]).. "x";
    -- end;
    -- element:setTexts(timeScale);
end;

function StockmanGui:onCreateAutoDayTimeScale(element)
	-- self.adts = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_AutoDayTimeScale');
	-- element.toolTipText = g_i18n:getText('gui_fn_AutoDayTimeScaleToolTip');
end;

function StockmanGui:onCreateShowHelp(element)
	-- self.shhe = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_ShowHelp');
	-- element.toolTipText = g_i18n:getText('gui_fn_ShowHelpToolTip');
end;

function StockmanGui:onCreateStartNightHour(element)
    -- self.snh = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_StartNightHour');
	-- element.toolTipText = g_i18n:getText('gui_fn_StartNightHourToolTip');	
    -- local hour = {};

    -- for i = 1, #fastnight.hourSteps, 1 do
    --     hour[i] = ""..tostring(fastnight.hourSteps[i]).. " h";
    -- end;
    -- element:setTexts(hour);
end;

function StockmanGui:onCreateStartNightMinute(element)
    -- self.snm = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_StartNightMinute');
	-- element.toolTipText = g_i18n:getText('gui_fn_StartNightMinuteToolTip');	
    -- local minute = {};

    -- for i = 1, #fastnight.minuteSteps, 1 do
    --     minute[i] = ""..tostring(fastnight.minuteSteps[i]).. " m";
    -- end;
    -- element:setTexts(minute);
end;

function StockmanGui:onCreateNightTimeScale(element)
    -- self.nts = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_NightTimeScale');
	-- element.toolTipText = g_i18n:getText('gui_fn_NightTimeScaleToolTip');	
    -- local timeScale = {};

    -- for i = 1, #fastnight.timeScaling, 1 do
    --     timeScale[i] = ""..tostring(fastnight.timeScaling[i]).. "x";
    -- end;
    -- element:setTexts(timeScale);
end;

function StockmanGui:onCreateAutoNightTimeScale(element)
	-- self.ants = element;
	-- element.labelElement.text = g_i18n:getText('gui_fn_AutoNightTimeScale');
	-- element.toolTipText = g_i18n:getText('gui_fn_AutoNightTimeScaleToolTip');		
end;

function StockmanGui:setStartDayHour(indexHour)
    self.sdh:setState(indexHour, false);
end;

function StockmanGui:setStartDayMinute(indexMinute)
    self.sdm:setState(indexMinute, false);
end;

function StockmanGui:setDayTimeScale(indexTimeScale)
    self.dts:setState(indexTimeScale, false);
end;

function StockmanGui:setAutoDayTimeScale(state)
    self.adts:setIsChecked(state);
end;

function StockmanGui:setShowHelp(state)
    self.shhe:setIsChecked(state);
end;

function StockmanGui:setStartNightHour(indexHour)
    self.snh:setState(indexHour, false);
end;

function StockmanGui:setStartNightMinute(indexMinute)
    self.snm:setState(indexMinute, false);
end;

function StockmanGui:setNightTimeScale(indexTimeScale)
    self.nts:setState(indexTimeScale, false);
end;

function StockmanGui:setAutoNightTimeScale(state)
    self.ants:setIsChecked(state);
end;