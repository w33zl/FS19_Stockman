local g_currentModDirectory = g_currentModDirectory
-- local DebugHelper = source(g_currentModDirectory .. "lib/debughelper.lua")
loadlib "modutility"
loadlib "tablehelper"

HusbandryStats = {}
local AnimalStats = {}

-- function Class(parentObject, className)
--     local newClass = parentObject or {}
--     newClass.__index = newClass
--     if className ~= nil then newClass.__type = className end
--     setmetatable(newClass, self)
--     return newClass
-- end
_G.translation = _G.translation or {}
-- _G.translation.fruits = {
--     GRASS = g_i18n:getText("fillType_grass"),
--     hafer = g_i18n:getText("fillType_oat"),
--     weizen = g_i18n:getText("fillType_wheat"),
--     SUGARBEET = g_i18n:getText("fillType_sugarBeet"),
--     POTATO = g_i18n:getText("fillType_potato"),
--     gerste = g_i18n:getText("fillType_barley"),
--     sojabohnen = g_i18n:getText("fillType_soybean"),
--     mischration = g_i18n:getText("fillType_forage"),
--     stroh = g_i18n:getText("fillType_straw"),
--     silage = g_i18n:getText("fillType_silage"),
--     heu = g_i18n:getText("fillType_dryGrass"),
--     mais = g_i18n:getText("fillType_maize"),
--     raps = g_i18n:getText("fillType_canola"),
--     wasser = g_i18n:getText("fillType_water"),
--     sonnenblumen = g_i18n:getText("fillType_sunflower"),
-- }


--* HUSBANDRIES STATS (MANAGER)

function HusbandryStats:new (husbandries)
    assert(husbandries, "Parameter 'husbandries' is required")

    -- DebugHelper.dumpkeys("g_currentMission.environment", g_currentMission.environment)

    -- print(g_currentMission.environment.realHourTimer)
    -- print(g_currentMission.environment.currentHour)
    -- print(g_currentMission.environment.timeUpdateTime)
    -- print(g_currentMission.environment.dayTime)
    -- print(g_currentMission.environment.timeUpdateTime)
    -- print(g_currentMission.environment.currentMinute)

    -- Enchance global fillTypeManager 
    source(g_currentModDirectory .. "lib/filltypemanager.lua")

    -- o = o or {}   -- create object if user does not provide one
    -- o.balance = o.balance or 0;
    -- local internal = {
    --     husbandries = husbandries
    -- }
    local UPDATE_INTERVAL = 0.5
    local husbandries = husbandries

    local self = {
        
        -- animalsStats = {},
        -- stats = 0,
        -- isInitialized =false,
        -- lastUpdated = 0,
        hasErrors = false,
        errors = {},
        lastError = "",
        -- fillTypeTexts = {},
        animals = {},
        
    }
    
    self.__index = self
    self.__type = nil --HusbandryStats
    -- self.lastUpdated = 0
    -- self.errors = { "" }

    -- self.add = function(self, value)
    --     self.is_ok = true
    -- end

    

    -- internal.refreshHusbandries = function()
    --     print("Do refresh")
    --     print(self)
    --     for _, husbandry in pairs(self.husbandries) do
    --         self[husbandry.modulesByName.animals.animalType] = AnimalStats:new(self, husbandry)

    --     end
    -- end

    -- self.updateHusbandries = function(self, force)
    --     -- Default values
    --     force = force or false;

    --     -- Do we need to update?
    --     local needsUpdate = force or (self.lastUpdated == 0) or ( (os.clock() - self.lastUpdated) > 1)
        
    --     if needsUpdate then 
    --         internal.refreshHusbandries()
    --         self.lastUpdated = os.clock()
    --         self.isInitialized = true
    --     else
    --         return 
    --     end
        
    -- end

    


    --TODO: Maybe refactor to support multiple pens for each animal?

    self.update = function(self)
        return not ModUtility.throttleExecution(self, UPDATE_INTERVAL, function()

            -- check where is the owner of every single husbandries.
            local farmData = {
                ownerFarmId = 0,
                farmId = 0,
            }
            local playerIsOwnerOfFarm = false
            local function checkisOwnerOfFarm(husbandry)
                if g_currentMission:getIsClient() then
                    farmData.ownerFarmID = g_currentMission.player.ownerFarmId
                    farmData.farmId = g_currentMission.player.farmId
                    
                    if husbandry.modulesByName.animals.owner.ownerFarmId == farmData.farmId then
                        playerIsOwnerOfFarm = true
                        return true
                    else
                        playerIsOwnerOfFarm = false
                        return false
                    end
                end
            end

            -- print(getDate("%c") .. ": Do refresh")
            self.animals = self.animals or {}
            for _, husbandry in pairs(husbandries) do
                if checkisOwnerOfFarm(husbandry) then
                    self.animals[husbandry.modulesByName.animals.animalType:lower()] = AnimalStats:new(husbandry)
                end
                -- self.animals[husbandry.modulesByName.animals.animalType:lower()] = AnimalStats:new(husbandry)

                -- print("New husbandry: " .. husbandry.modulesByName.animals.animalType:lower())
                
                -- print(husbandry.modulesByName.animals.animalType:lower())
                -- self[husbandry.modulesByName.animals.animalType] = AnimalStats:new(self, husbandry)
    
            end
        end);

    end

    -- self.getFillTypeText = function(fillTypeId)
    --     if fillTypeTexts[fillTypeId] == nil then
    --         local defaultText = g_currentMission.fillTypeManager.fillTypes[fillTypeId]
    --         fillTypeTexts[fillTypeId] = defaultText
    --     end
    --     return fillTypeTexts[fillTypeId]
        
    -- end

    local function err(self, text)
        table.insert(self.errors, text)
        self.lastError = text
        self.hasErrors = true
        return
    end

    if husbandries == nil then err(self, "Husbandires cannot be empty") end

    -- self = o
    setmetatable(self, self)

    -- self:update()

    return self
end


--*** CLASS: AnimalStats***

--- AnimalStats constructor
function AnimalStats:new (husbandry)
    assert(husbandry)
    assert(husbandry.modulesByName.animals)
    -- o = o or {}   -- create object if user does not provide one
    -- o.balance = o.balance or 0;
    local husbandry = husbandry

    local defaultValues = {
        -- parent = husbandriesStatsParent,
        
        -- isInitialized =false,
        -- lastUpdated = 0,
        essentials = {},
        food = {},
        output = {},
        -- productivity = {},
        condition = {},
        -- test = "opk",
    }
    setmetatable(defaultValues, self)
    self = defaultValues
    -- print(self.test)
    self.__index = self
    self.__type = nil --AnimalStats

    self.animalType = husbandry.modulesByName.animals.animalType

    -- DebugHelper.dumptable("husbandry.modulesByName.animals", husbandry.modulesByName.animals)

    self.animalCount = table.length(husbandry.modulesByName.animals.animals)

    self.mapHotspots = husbandry.mapHotspots
    self.husbandryID = husbandry.id

    self.hasAnimals = function(self)
        return self.animalCount > 0
    end

    -- print("Analyzing " .. self.animalType .. ": " .. tostring(self.animalCount))
    -- foodSpillage


    -- local function extractDataForSingleNamedFillType(name)
    --     local module = husbandry.modulesByName[name]
    --     if module then 
    --         print("Has " .. name) 
    --         local fillType = g_currentMission.fillTypeManager:getFilltypeByName(name)
    --         print("Index is: " .. tostring(fillType.index))
    --         local fillLevel = module.fillLevels[fillType.index]

    --         return {
    --             title = fillType.title,
    --             fillLevel = fillLevel,
    --             fillCapacity = module.fillCapacity,
    --             percentageFillLevel = math.floor(fillLevel / module.fillCapacity),
    --         }

    --     end
    -- end

    local function DEBUG_PRINT_MODULE(module)
        local out = "DBG: [" .. self.animalType .. "]->" .. module.moduleName .. ": "

        out = out .. "Animals=" .. tostring(self.animalCount) .. "\t"
        out = out .. "Use/day=" .. tostring(module.singleAnimalUsagePerDay) .. "\t"
        out = out .. "fillCapacity=" .. tostring(module.fillCapacity) .. "\t"

        out = out .. "fillLevels=(" .. tostring(module.fillCapacity)
        for key, value in pairs(module.fillLevels) do
            out = out .. key .. "|" .. value .. "),("
        end
        out = out .. ")\t"

        print(out)

        -- DebugHelper.dumptable("[" .. self.animalType .. "]->" .. module.moduleName .. " RAW", module)
    end

    local function extractDataForSingleFillType(name)
        local module = husbandry.modulesByName[name]
        if module then
            -- print("Has " .. name)

            --fillTypeIndex
            --providedFillTypes

            -- DEBUG_PRINT_MODULE(module)


            -- Try to find the (primary) fillTypeId - direct access is better than iterator..
            --TODO: Maybe there is a better way than taking the randomly first item
            local fillTypeId
            if name == "foodSpillage" and module.spillageFillType then
                fillTypeId = module.spillageFillType
            elseif module.fillTypeIndex and type(module.fillTypeIndex) == "number" then
                fillTypeId = module.fillTypeIndex
            else -- Lastly try to find a (the first) filltype using a "best effort"-approcha using a iterator
                fillTypeId = next(module.fillLevels)
            end

            if fillTypeId == nil then
                print("Warning: Failed to extract fillTypeId for module '" .. name .. "' (husbandry: " .. husbandry.animalType .. ")")
                return nil
            end

            local fillType = g_currentMission.fillTypeManager.fillTypes[fillTypeId]

            assert(fillType ~= nil, "Filltype #" .. fillTypeId .. " was not found")
            -- print("Index is: " .. tostring(fillType.index))

            local fillLevel = module.fillLevels[fillType.index] or 0

            local totalAmountNeededPerDay, estimatedDaysLeft, percentageFillLevel, weight




            if module.singleAnimalUsagePerDay and self.animalCount > 0 then
                totalAmountNeededPerDay = (module.singleAnimalUsagePerDay * self.animalCount)
            end

            -- Perform some calculations on fill level (but only if we have a fill level and where it is relevent)
            if fillLevel then -- and name ~= "foodSpillage" then
                percentageFillLevel = math.floor((fillLevel / module.fillCapacity) * 100)
                weight = (fillLevel * fillType.massPerLiter) * 1000
                if totalAmountNeededPerDay and totalAmountNeededPerDay > 0 then
                    estimatedDaysLeft = (fillLevel / totalAmountNeededPerDay)
                end
            end

            -- if name == "foodSpillage" then
            --     print("module.singleAnimalUsagePerDay: " .. module.singleAnimalUsagePerDay)
            -- end

            -- print(fillType.title .. ": " .. totalAmountNeededPerDay .. " / " .. estimatedDaysLeft)

            local returnValue = {
                title = fillType.title,
                fillLevel = fillLevel,
                singleAnimalUsagePerDay = module.singleAnimalUsagePerDay,
                totalAmountNeededPerDay = totalAmountNeededPerDay,
                estimatedDaysLeft = estimatedDaysLeft,
                capacity = module.fillCapacity,
                percentageFillLevel = percentageFillLevel,
                weight = weight
            }

            

            -- Additionals/specials
            if name == "foodSpillage" then
                --providedFillTypes
                --spillageFillType
                --foodToDrop
                returnValue.cleanlinessFactor = math.floor(module.cleanlinessFactor * 100)
            end

            -- if name == "foodSpillage" then
            --     print("module.cleanlinessFactor: " .. module.cleanlinessFactor)
            -- end

            -- DebugHelper.dumptable("[" .. self.animalType .. "]->" .. module.moduleName:upper() .. " STATS: ", returnValue)

            return returnValue
        end
    end

    local function getFillLevelData(module)
        local name = module.moduleName
            --fillTypeIndex
            --providedFillTypes

        -- Try to find the (primary) fillTypeId - direct access is better than iterator..
        --TODO: Maybe there is a better way than taking the randomly first item
        local fillLevelTypeId, outputFillTypeId
        if name == "foodSpillage" and module.spillageFillType then
            fillLevelTypeId = module.spillageFillType
        elseif name == "pallets" and module.palletFillUnitIndex then
            fillLevelTypeId = module.palletFillUnitIndex -- the index of the technical filltype that will actual "drop" (UNKNOWN)
            outputFillTypeId = module.palletFillTypeIndex -- the index of the expected filltype (wool, egg etc)
        elseif module.fillTypeIndex and type(module.fillTypeIndex) == "number" then
            fillLevelTypeId = module.fillTypeIndex
        else -- Lastly try to find a (the first) filltype using a "best effort"-approcha using a iterator
            fillLevelTypeId = next(module.fillLevels)
        end

        if fillLevelTypeId == nil then
            print("Warning: Failed to extract fillTypeId for module '" .. name .. "' (husbandry: " .. husbandry.animalType .. ")")
            return nil
        end


        local outputFillType
        local fillLevelType = g_currentMission.fillTypeManager.fillTypes[fillLevelTypeId]
        assert(fillLevelType ~= nil, "Filltype #" .. fillLevelTypeId .. " was not found")

        -- If there is no "other" output filltype the use the fill level type as fallback
        if outputFillTypeId == nil then
            outputFillType = fillLevelType
        else
            outputFillType = g_currentMission.fillTypeManager.fillTypes[outputFillTypeId]
        end

        -- print("Index is: " .. tostring(fillType.index))

        --local fillLevel = module.fillLevels[fillType.index] or 0    
        return (module.fillLevels[fillLevelType.index] or 0), outputFillType
    end

    local function extractDataForSpecialFilltype(name)
        local module = husbandry.modulesByName[name]
        if module then
            -- print("Has " .. name)

            -- DEBUG_PRINT_MODULE(module)

            local fillLevel, fillType = getFillLevelData(module)

            local totalAmountNeededPerDay, estimatedDaysLeft, percentageFillLevel, weight

            if module.singleAnimalUsagePerDay and self.animalCount > 0 then
                totalAmountNeededPerDay = (module.singleAnimalUsagePerDay * self.animalCount)
            end

            -- Perform some calculations on fill level (but only if we have a fill level and where it is relevent)
            if fillLevel then -- and name ~= "foodSpillage" then
                percentageFillLevel = math.floor((fillLevel / module.fillCapacity) * 100)
                weight = (fillLevel * fillType.massPerLiter) * 1000
                if totalAmountNeededPerDay and totalAmountNeededPerDay > 0 then
                    estimatedDaysLeft = (fillLevel / totalAmountNeededPerDay)
                end
            end

            -- if name == "foodSpillage" then
            --     print("module.singleAnimalUsagePerDay: " .. module.singleAnimalUsagePerDay)
            -- end

            -- print(fillType.title .. ": " .. totalAmountNeededPerDay .. " / " .. estimatedDaysLeft)

            local returnValue = {
                title = fillType.title,
                fillLevel = fillLevel,
                singleAnimalUsagePerDay = module.singleAnimalUsagePerDay,
                totalAmountNeededPerDay = totalAmountNeededPerDay,
                estimatedDaysLeft = estimatedDaysLeft,
                capacity = module.fillCapacity,
                percentageFillLevel = percentageFillLevel,
                weight = weight
            }

            -- Additionals/specials
            if name == "foodSpillage" then
                --providedFillTypes
                --spillageFillType
                --foodToDrop
                returnValue.cleanlinessFactor = math.floor(module.cleanlinessFactor * 100)

                -- print("["  .. self.animalType .. "] CLEANLI-DEBUG: " .. module.cleanlinessFactor .. " / " .. module.foodToDrop)
                -- print("["  .. self.animalType .. "] CLEANLI-FILLS: " .. fillLevel .. " / " .. module.fillCapacity)
                -- for key, value in pairs(module.fillLevels) do
                --     print("> " .. key .. ": " .. value)
                -- end
                -- for key, value in pairs(module.providedFillTypes) do
                --     print(">> " .. key .. ": " .. tostring(value))
                -- end
            elseif name == "pallets" then
                -- --palletFillUnitIndex=1 (has)
                -- -- palletFillTypeIndex=14 (has not)

                -- -- print("["  .. self.animalType .. "] CLEANLI-DEBUG: " .. module.cleanlinessFactor .. " / " .. module.foodToDrop)
                -- print("["  .. self.animalType .. "] PALLETS-FILL: " .. fillLevel .. " / " .. module.fillCapacity)
                -- for key, value in pairs(module.fillLevels) do
                --     print(">>> " .. key .. ": " .. value)
                -- end
                -- for key, value in pairs(module.providedFillTypes) do
                --     print(">>>> " .. key .. ": " .. tostring(value))
                -- end
            elseif name == "milk" then
                -- --palletFillUnitIndex=1 (has)
                -- -- palletFillTypeIndex=14 (has not)

                -- -- print("["  .. self.animalType .. "] CLEANLI-DEBUG: " .. module.cleanlinessFactor .. " / " .. module.foodToDrop)
                -- print("["  .. self.animalType .. "] MILK-FILL: " .. fillLevel .. " / " .. module.fillCapacity)
                -- for key, value in pairs(module.fillLevels) do
                --     print("MILK >> " .. key .. ": " .. tostring(value))
                -- end
                -- for key, value in pairs(module.providedFillTypes) do
                --     print("MILK2 >> " .. key .. ": " .. tostring(value))
                -- end
            elseif name == "liquidManure" then
                -- --palletFillUnitIndex=1 (has)
                -- -- palletFillTypeIndex=14 (has not)

                -- -- print("["  .. self.animalType .. "] CLEANLI-DEBUG: " .. module.cleanlinessFactor .. " / " .. module.foodToDrop)
                -- print("["  .. self.animalType .. "] SLURRY-FILL: " .. fillLevel .. " / " .. module.fillCapacity)
                -- for key, value in pairs(module.fillLevels) do
                --     print("SLURRY >> " .. key .. ": " .. tostring(value))
                -- end
                -- for key, value in pairs(module.providedFillTypes) do
                --     print("SLURRY2 >> " .. key .. ": " .. tostring(value))
                -- end
            end

            -- if name == "foodSpillage" then
            --     print("module.cleanlinessFactor: " .. module.cleanlinessFactor)
            -- end

            -- DebugHelper.dumptable("[" .. self.animalType .. "]->" .. module.moduleName:upper() .. " STATS: ", returnValue)

            return returnValue
        end
    end


    -- CONDITION / STATE
    self.condition.cleanliness = extractDataForSpecialFilltype("foodSpillage") -- foodSpillage/Cleanliness

    if husbandry.globalProductionFactor then
        self.condition.productivity = math.floor(husbandry.globalProductionFactor * 100)
    end

    -- ESSENTIALS
    self.essentials.straw = extractDataForSingleFillType("straw") -- Straw
    self.essentials.water = extractDataForSingleFillType("water") -- Water

    -- OUTPUT / PRODUCE
    self.output.manure = extractDataForSingleFillType("manure") -- Manure
    self.output.slurry = extractDataForSpecialFilltype("liquidManure") -- Slurry / liquid manure
    self.output.produce = extractDataForSpecialFilltype("pallets") -- Produce
    self.output.milk = extractDataForSpecialFilltype("milk") -- Milk


    do -- FOOD
        local food = husbandry.modulesByName.food
        if food then
            -- print("Has food") 
            -- DEBUG_PRINT_MODULE(food)
            local foodGroups = {}
            local totalAmountOfFood = 0
            local totalFoodCapacity = 0
            for _,foodGroupCapacity in pairs(food.foodGroupCapacities) do
                local foods = {}
                local foodGroupFillLevel = 0
                -- DebugHelper.dumpkeys("foodGroupCapacity", foodGroupCapacity)
                for _, fillTypeId in pairs(foodGroupCapacity.foodGroup.fillTypes) do
                    local fillType = g_currentMission.fillTypeManager.fillTypes[fillTypeId]
                    local fillLevel = food.fillLevels[fillTypeId]
                    foodGroupFillLevel = foodGroupFillLevel + fillLevel
                    local foodType = {
                        title = fillType.title,
                        fillTypeId = fillType.index,
                        fillLevel = fillLevel,
                        weight = (fillLevel * fillType.massPerLiter) * 1000,
                    }
                    table.insert(foods, foodType)
                end
                local foodGroup = {
                    title = foodGroupCapacity.foodGroup.title,
                    productionWeight = foodGroupCapacity.foodGroup.productionWeight,
                    eatWeight = foodGroupCapacity.foodGroup.eatWeight,
                    foods = foods,
                    capacity = foodGroupCapacity.capacity,
                    fillLevel = foodGroupFillLevel,
                    percentageFillLevel = math.floor((foodGroupFillLevel / foodGroupCapacity.capacity) * 100),
                }
                totalAmountOfFood = totalAmountOfFood + foodGroupFillLevel
                totalFoodCapacity = totalFoodCapacity + foodGroupCapacity.capacity
                table.insert(foodGroups, foodGroup)
            end

            self.food = {
                singleAnimalUsagePerDay = food.singleAnimalUsagePerDay,
                totalFoodNeededPerDay = (food.singleAnimalUsagePerDay * self.animalCount),
                foodGroups = foodGroups,
                totalAmountOfFood = totalAmountOfFood,
                totalFoodCapacity = totalFoodCapacity,
                estimatedDaysLeft = 0.0,
            }
            if self.food.totalFoodNeededPerDay > 0 then
                self.food.estimatedDaysLeft = (self.food.totalAmountOfFood / self.food.totalFoodNeededPerDay)
            end

            -- print("[" .. self.animalType .. "] FOOD: perDay=" .. food.singleAnimalUsagePerDay .. ", totPerDay=" .. self.food.totalFoodNeededPerDay .. ", total=" .. totalAmountOfFood .. ", capacity=" .. totalFoodCapacity)

            local totalFoodLevel, totalFoodCapacity = 0, 0

            -- local isPrimaryFood = false
            -- isPrimaryFood = isPrimaryFood or (self.animalType == "COW" and (FILL TYPE ID FROM LOOP??)) == g_currentMission.fillTypeManager:getFilltypeByName("forage"))
            
            local isTotalAmountOfFoodMore

        --     local x = next(husbandry.modulesByName.pallets.fillLevels)
            -- DebugHelper.dumpkeys("food", food)
            -- DebugHelper.dumptable("food.fillCapacity", food.fillCapacity)
            -- DebugHelper.dumptable("food.foodGroupCapacities", food.foodGroupCapacities)
            -- DebugHelper.dumptable("food.singleAnimalUsagePerDay", food.singleAnimalUsagePerDay)
            -- DebugHelper.dumptable("food.foodFactor", food.foodFactor)
            -- fillCapacity
            -- foodGroupCapacities
            -- singleAnimalUsagePerDay
            -- fillLevels
            -- foodFactor
            -- DebugHelper.dumptable("food.fillLevels", food.fillLevels)

        --         DebugHelper.dumpkeys("husbandry.modulesByName.pallets", husbandry.modulesByName.pallets.fillLevels)
        end
    end

    return self
end

return HusbandryStats