ModUtility = {}

local getDate = _G.getDate or function(format) return os.date(format) end

local function getTime()
    return loadstring("return " .. getDate("( %H * 3600 ) + ( %M * 60 ) + %S"))()
end

ModUtility.executonThrottles = {}
function ModUtility.throttleExecution(stateObject, minSecondsBetweenExecutions, callbackMethod)
    local lastUpdate = ModUtility.executonThrottles[stateObject] or 0 --ModLib.TIME_ZERO
    local elapsed = getTime() - lastUpdate
    local shouldThrottle = (lastUpdate > 0) and (minSecondsBetweenExecutions > elapsed)

    if shouldThrottle then
        return true
    else
        if callbackMethod ~= nil then callbackMethod() end
        ModUtility.executonThrottles[stateObject] = getTime()
        return false
    end

end

return ModUtility