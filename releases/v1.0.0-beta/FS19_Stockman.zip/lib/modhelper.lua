local function NewClass(baseClass)
    baseClass = baseClass or {}
    local derivedClass = {}
    derivedClass.__index = derivedClass

    setmetatable(derivedClass, {
    __index = baseClass, -- this is what makes the inheritance work
    __call = function (cls, ...)
        local self = setmetatable({}, cls)
        -- self:_init(...)
        return self
    end,
    })

    return derivedClass
end

local currentDirectory

if _G.g_currentModDirectory and _G.g_currentModDirectory ~= "" then
    currentDirectory = _G.g_currentModDirectory
else
    currentDirectory = ""
end

--- Unpack (fallback) method
---@param t table
local unpack = _G.unpack
if not unpack then
    unpack = function (t, i)
        i = i or 1
        if t[i] ~= nil then
          return t[i], unpack(t, i + 1)
        end
      end    
end

local source = source or dofile

_G.LIBCACHE = _G.LIBCACHE or {}
_G.LIBCACHE[currentDirectory] = _G.LIBCACHE[currentDirectory] or {}

local currentLibCache = _G.LIBCACHE[currentDirectory]

-- print(string.gsub("Hello\\Lua/u ser", "([\\ /])", ".")) 
-- print(string.gsub("Hello\\Lua/u ser.lua", "\.lua$", print)) 

local function tryToGetLib(filename)
    local oldGlobalFetch = _G.LIB
    source(filename)
    local newLib = _G.LIB
    _G.LIB = oldGlobalFetch
    return newLib
end

function initlib(name, libTable)
    currentLibCache[name:lower()] = libTable
    return libTable
end

function require(name)
    local cachedLib = currentLibCache[name:lower()]

    if cachedLib == nil then
        loadlib(name)
        cachedLib = currentLibCache[name:lower()]
    end
    return cachedLib
end


local function loadlib(filename, ...)
    local args = {...}
    local loadedLib
    if fileExists(currentDirectory .. filename) then
        loadedLib = source(currentDirectory .. filename)
    else
        local paths = {
            "",
            "lib/",
            currentDirectory,
            currentDirectory .. "lib/"
        }

        local filenames = {
            filename,
            filename .. ".lua",
        }

        for _,path in pairs(paths) do
            for _,filename in pairs(filenames) do
                if fileExists(path .. filename) then
                    loadedLib = source(path .. filename)
                end
            end
        end

    end

    if args and args[1] then
        local out = nil
        for i,v in ipairs(args) do
            assert(type(v) == "string", "Argument #" .. (i + 1) .. " of loadlib() must be of type string (was " .. type(v) .. ")")
            out = out or {}
            local obj = loadedLib[v]
            if obj then   
                table.insert( out, obj )
            else
                print("Error: Could not find submodule '" .. v .. "' in library '" .. filename .. "'")
            end
        end

        if out then
            return unpack(out)
        else
            return nil
        end
    else
        return loadedLib
    end
end
_G.loadlib = loadlib

-- if not _G.source then
--     _G.source = dofile
-- end

-- local MODify = {}
function NewMod(name, version, objectToMODify)
    local newMod = NewClass(objectToMODify)
    newMod.modName = name
    newMod.version = version
    newMod.dir = currentDirectory or ""

    newMod.dir2 = ""

    if currentDirectory and currentDirectory ~= "" then
        newMod.dir2 = tostring(currentDirectory)
    end

    newMod.loaded = function(self)
        print("############################################################")
        print("--- " .. self.modName .. " v" .. self.version .. " by " .. (self.author or "Unknown author"))
        print("############################################################")
    end

    addModEventListener(newMod);
    return newMod
end
