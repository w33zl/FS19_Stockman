local g_Overlay = Overlay

local function SETTINGS() return {
    defaultFont = FONT.NORMAL
}end

--*** SHARED LOCALS / CONSTANTS / SETTINGS ***
-- local SCREEN_WIDTH, SCREEN_HEIGHT = (g_screenWidth or 1920), (g_screenHeight or 1080)
local SCREEN_WIDTH, SCREEN_HEIGHT = 1920, 1080
local PIXEL_PER_UNIT = ((100 / SCREEN_WIDTH) / 100) -- 100% / FullHD width=1920px == px per percent / 100%
local Y_PIXEL_RATIO = g_screenAspectRatio or (SCREEN_WIDTH/SCREEN_HEIGHT)
local UI_SCALE = g_gameSettings.uiScale or 1.0
local SCALED_PIXEL_PER_UNIT = PIXEL_PER_UNIT * UI_SCALE
local SPXU = SCALED_PIXEL_PER_UNIT
local RU_PER_PX_X, RU_PER_PX_Y
--TODO: refactor to use two constants (X,Y) and with support to change scale per mod
local function pixels(pixelX, pixelY)
    pixelY = pixelY or pixelX
    return {
        x = pixelX * SPXU,
        y = pixelY * SPXU * Y_PIXEL_RATIO,
    }
end
local function pixel(pixelX)
    return pixels(pixelX).x
end
local function pixelY(pixel)
    return pixels(pixel).y
end

--- Gets the pixel dimension in scaled relative screen units
---@param pixel integer float
---@param pixel2 integer float
local function getScaledUnitFromPixel(pixel1, pixel2)
    --TODO: Fix bug
    if pixel2 then
        local RU = pixels(pixel1, pixel2)
        return RU.x, RU.y
    else
        return pixel(pixel1)
    end
end


function RGBA(r, g, b, a) return { r/255, g/255, b/255, a/100 } end
function RGB(r, g, b, a) return RGBA(r, g, b, 100) end

COLOR = {
    -- Full opacity colors
    BLACK = RGB(0, 0, 0),
    WHITE = RGB(255, 255, 255),
    GRAY = RGB(192, 192, 192),
    RED = RGB(255, 0, 0),
    YELLOW = RGB(255, 255, 0),
    GREEN = RGB(0, 255, 0),

    -- Colors with reduced opacity setting
    BLACK_20 = RGBA(0, 0, 0, 20),
    BLACK_40 = RGBA(0, 0, 0, 40),
    BLACK_50 = RGBA(0, 0, 0, 50),
    BLACK_75 = RGBA(0, 0, 0, 75),
    BLACK_80 = RGBA(0, 0, 0, 80),
    GRAY_80 = RGBA(192, 192, 192, 80),


    -- Colors for specific purposes
    BLACK_BG = RGBA(0, 0, 0, 25),
    TEXT_SHADOW = RGBA(0, 0, 0, 75),
    WARNING = RGB(248, 239, 24),
    CRITICAL = RGB(208, 93, 77),
    GOOD = RGB(198, 255, 186),
}

TEXTALIGN = {
    LEFT = 1,
    CENTER = 2,
    RIGHT = 3,
}

local FONT_SIZE_FACTOR = 1 / UI_SCALE
local BASE_FONT_SIZE = FONT_SIZE_FACTOR * 17 -- 23 --22
FONTSIZE = {
    NORMAL = pixel(BASE_FONT_SIZE),
    LARGE = pixel(BASE_FONT_SIZE * 1.2),
    HEADLINE = pixel(BASE_FONT_SIZE * 1.5),
    SMALL = pixel(BASE_FONT_SIZE * 0.85),
}

FONT = {
    SMALL = { size = FONTSIZE.SMALL, bold = false },
    THIN = { size = FONTSIZE.NORMAL, bold = false },
    NORMAL = { size = FONTSIZE.NORMAL, bold = true },
    -- STRONG = { size = FONTSIZE.NORMAL, bold = true },
    FOCUSED = { size = FONTSIZE.LARGE, bold = false },
    HEADLINE = { size = FONTSIZE.HEADLINE, bold = false },
}

LAYOUT = {
    HORIZONTAL = 0,
    HORIZONTAL_RIGHT = 0,
    HORIZONTAL_RIGHT_ALIGN = 2,
    HORIZONTAL_LEFT = 2,
    VERTICAL = 1,
    VERTICAL_DOWN = 1,
    VERTICAL_UP = 3,
}



--*** SUPPORT FUNCTIONS AND DEFAULT OVERRIDES ***

local g_setTextColor = setTextColor
local function setTextColor(...)
    local arg = {...}
    if type(arg[1]) == "table" then
        g_setTextColor(unpack(arg[1]))
    else
        g_setTextColor(...)
    end
end


local function NewClass(baseClass)
    baseClass = baseClass or {}
    local derivedClass = {}
    derivedClass.__index = derivedClass

    setmetatable(derivedClass, {
    __index = baseClass, -- this is what makes the inheritance work
    __call = function (cls, ...)
        local self = setmetatable({}, cls)
        -- self:_init(...)
        return self
    end,
    })

    return derivedClass
end

local function inherit(baseClass, object)
    local newClass = setmetatable(object or {}, {__index = baseClass })
    newClass.__index = newClass
    return newClass
end



local function InheritClass(derivedClass, baseClass)
    baseClass = baseClass or {}
    derivedClass = derivedClass or {}
    derivedClass.__index = derivedClass
    derivedClass.__base = baseClass

    setmetatable(derivedClass, {
    __index = baseClass, -- this is what makes the inheritance work
    __call = function (cls, ...)
        local self = setmetatable({}, cls)
        -- self:_init(...)
        return self
    end,
    })

    return derivedClass
end


--*** RENDERMAN ***

local Renderman = {}

Renderman.getScaledUnitFromPixel = getScaledUnitFromPixel

--- Gets the pixel dimension in scaled relative screen units
---@param x integer float
---@param y integer float
function Renderman.getScaledUnitSizeFromPixels(x, y)
    return Renderman.getScaledUnitFromPixel(x), Renderman.getScaledUnitFromPixel(y)
end



function Renderman.createOverlay(imageUrl, anchorMode)
    return Overlay:new(imageUrl, anchorMode)
end


function Renderman.render(overlay)
end


--*** TEXTOVERLAY ***

local TextOverlay = {}
Renderman.TextOverlay = TextOverlay
function TextOverlay:new(backgroundOrSettings, x, y, width, height, padding)

    local self = setmetatable({}, { __index = self } )
    self.__index = self

    self.x = x or getScaledUnitFromPixel(200)
    self.y = y or getScaledUnitFromPixel(200)
    self.width = width or getScaledUnitFromPixel(100)
    self.height = height or getScaledUnitFromPixel(50)
    self.padding = padding or 0
    self.fontSize = FONTSIZE.NORMAL
    self.lineHeight = 1.2
    self.background = backgroundOrSettings
    self.hasBackground = false
    self.verticalAlign = g_Overlay.ALIGN_VERTICAL_TOP
    self.horizontalAlign = g_Overlay.ALIGN_HORIZONTAL_LEFT
    self.color = RGBA(0, 0, 0, 25)
    self.readyToFlush = true
    self.visible = true
    self.tableMode = false
    self.shadows = false

    -- Unpack default values if initialized with a settings-table instead of explicit values
    if type(backgroundOrSettings) == "table" then
        local backgroundImage = backgroundOrSettings.background
        for key, value in pairs(backgroundOrSettings) do
            self[key] = value
        end
        self.background = backgroundImage -- Special override of the table with the named key
    end

    if self.padding and type(self.padding) == "number" then
        local paddingValue = self.padding + 0
        self.padding = { x = paddingValue, y = paddingValue }
    end
    if backgroundOrSettings and backgroundOrSettings ~= "" then
        self.bgOverlay = g_Overlay:new( self.background, self.x, self.y, self.width, self.height)
        self.hasBackground = (self.bgOverlay ~= nil)

        self.bgOverlay:setColor( unpack ( self.color ) )
    end

    self.defaultWidth = width
    self.defaultHeight = height
    self.startPositionX = self.x
    self.startPositionY = self.y

    self.updateTextDimensions = function(self, newTextWidth, newLineHeight)
        self.textWidth = math.max( (self.textWidth or 0), newTextWidth)
        self.textHeight = (self.textHeight or 0) + newLineHeight
    end

    self.resizeBox = function(self)
        -- Handle special rendering mode for tables
        if self.tableMode then
            -- Recalculate column widths
            local columnWidths = {}
            -- First pass finds out the max width of each column
            for _, line in ipairs(self.content) do
                for colIndex, column in ipairs(line.columns) do
                    columnWidths[colIndex] = math.max( (columnWidths[colIndex] or 0), column.width )
                end
            end
            -- Second pass sets the max width to every column
            for _, line in ipairs(self.content) do
                for colIndex, column in ipairs(line.columns) do
                    column.width = columnWidths[colIndex]
                end
            end
            local totalWidth = 0
            for _,width in ipairs(columnWidths) do
                totalWidth = totalWidth + width
            end
            self:updateTextDimensions(totalWidth, 0)
        end
        
        -- self.textWidth = self.textWidth or 0
        local boxWidth = (self.padding.x * 2) + (self.textWidth or self.defaultWidth) --TODO: add space for icon?
        local boxHeight = (self.padding.y * 2) + (self.textHeight or self.defaultHeight)

        -- Move box to preserve location
        self.width = boxWidth
        self.height = boxHeight

        if self.horizontalAlign == g_Overlay.ALIGN_HORIZONTAL_RIGHT then
            self.x = 1 - self.startPositionX - self.width
        elseif self.horizontalAlign == g_Overlay.ALIGN_HORIZONTAL_CENTER then
            self.x = 0.5 - (self.startPositionX / 2) - (self.width / 2)
        else
            self.x = self.startPositionX
        end

        if self.verticalAlign == g_Overlay.ALIGN_VERTICAL_TOP then
            self.y = 1 - self.startPositionY - self.height
        elseif self.verticalAlign == g_Overlay.ALIGN_VERTICAL_MIDDLE then
            self.y = 0.5 - self.startPositionY - (self.height / 2)
        else
            self.y = self.startPositionY
        end

        self.bgOverlay:setPosition(self.x, self.y)
        self.bgOverlay:setDimension(self.width, self.height)
    end

    self:reset()
    return self
end

local function calculateTextboxDimensions(content)
    return 10, 10
end

local function calculateOuterDimensions(width, height)
    return 10, 10
end

function TextOverlay:writeLine(text, color)
end

function TextOverlay:setPosition(x, y)
    self.x = x
    self.y = y
    self.bgOverlay:setPosition(self.x, self.y)
end

local function getColumnStyleWithDefaults(style)
    style = style or {}
    style.color = style.color or COLOR.WHITE
    style.bold = style.bold or false
    style.size = style.size or FONTSIZE.NORMAL
    style.align = style.align or RenderText.ALIGN_LEFT
    style.spacing = style.spacing or 0
    style.padChar = style.padChar or "."
    return style
end

--TODO: refactor to be able to write "tables" with variable amount of columns
function TextOverlay:writeColumns(text1, text2, fixedWidth1, fixedWidth2, style1, style2)
    if self.readyToFlush then self:reset() end

    style1 = getColumnStyleWithDefaults(style1)
    style2 = getColumnStyleWithDefaults(style2)

    text2 = text2 or ""

    local columns = {
        {
            text = text1,
            style = style1,
            length = getTextLength(style1.size, text1, 1),
            width = fixedWidth1 or getTextWidth(style1.size, text1) + style1.spacing,
            height = getTextHeight(style1.size, text1),
        },
        {
            text = text2,
            style = style2,
            length = getTextLength(style2.size, text2, 1),
            width = fixedWidth2 or getTextWidth(style2.size, text2) + style2.spacing,
            height = getTextHeight(style2.size, text2),
        }
    }

    local totalWidth = columns[1].width + columns[2].width
    local totalHeight = math.max(columns[1].height, columns[2].height) * self.lineHeight

    local newLine = {
        lineWidth = totalWidth,
        lineHeight = totalHeight,
        columns = columns,
    }

    self:updateTextDimensions(totalWidth, totalHeight)

    table.insert( self.content, newLine )
end

function TextOverlay:write(text, minWidth, style)
    self:writeColumns(text, "", minWidth, nil, style, nil)
end

function TextOverlay:setColor(r, g, b, alpha)
    self.bgOverlay:setColor(r, g, b, alpha)
end

function TextOverlay:reset()
    self.content = {}
    self.text = ""
    self.textWidth = 0
    self.textHeight = 0
    self.width = self.defaultWidth
    self.height = self.defaultHeight
    self.readyToFlush = false
end

function TextOverlay:render()

    if self.isRendering then return end -- Throttle if we got parallell rendering (is it even possible?)

    self.isRendering = true

    -- Update position and dimensions
    self:resizeBox()

    -- Render background
    self.bgOverlay:render()

    -- Render foreground
    local function getTextStartPositionX()
        return self.x + self.padding.x
    end
    local function getTextStartPositionY()
        return self.y + self.height + self.padding.y + Renderman.PX2U(5)
    end

    local currentX, currentY = getTextStartPositionX(), getTextStartPositionY()
    local renderDirectionY = -1

    for i,line in ipairs(self.content) do
        -- Advance Y position one lineheight per line of text
        currentY = currentY + (line.lineHeight * renderDirectionY)

        for colIndex,column in ipairs(line.columns) do
            local textOffsetX = 0
            -- Adjust for right alignment of text
            if column.style.align == RenderText.ALIGN_RIGHT then
                currentX = currentX + column.width
                -- currentX = currentX + self.textWidth
            end

            -- Append margin to the first column before rendering text
            if colIndex == 1 then
                currentX = currentX + self.padding.x
            end

            -- Set text rendering options
            setTextBold(column.style.bold)
            setTextAlignment(column.style.align or RenderText.ALIGN_LEFT)

            -- Render shadow
            if self.shadows == true then
                setTextColor(COLOR.TEXT_SHADOW)
                local shadowOffsetX,shadowOffsetY = 0.0005, (renderDirectionY * 0.0005)
                renderText(currentX + shadowOffsetX, currentY + shadowOffsetY, column.style.size or self.fontSize, column.text)
            end

            -- Render actual text
            setTextColor(column.style.color or COLOR.WHITE)
            renderText(currentX, currentY, column.style.size or self.fontSize, column.text)

            -- Advance X position based on text direction
            -- currentX = currentX + column.width
            if column.style.align == RenderText.ALIGN_LEFT then
                currentX = currentX + column.width
            end

            -- -- Append margin to the last column after rendering text
            -- if colIndex == table.length(line.columns) then
            --     currentX = currentX + self.padding.x
            -- end
        end

        -- print(i,v)

        -- Reset X position after every line
        currentX = getTextStartPositionX()
    end

    -- Reset text alignment and style after render
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(COLOR.WHITE)

    self.readyToFlush = true
    self.isRendering = false
end


local OverlayGroup = {}

function OverlayGroup:new(backgroundImage, x, y, spacing)
    assert(type(backgroundImage) == "string" or type(backgroundImage) == "table")

    local settings = {}

    if backgroundImage and type(backgroundImage) == "table" then
        settings = backgroundImage
    end

    --TODO: fix ctor
    local self = setmetatable( settings, { __index = self } )
    self.__index = self

    self.direction = LAYOUT.HORIZONTAL
    self.align = Overlay.ALIGN_HORIZONTAL_LEFT
    self.overlays = {}

    if backgroundImage and backgroundImage ~= "" then
        self.background = g_Overlay:new( backgroundImage, 0.0, 0.0, 0.005, 0.005)
    end
    self.hasBackground = (self.background ~= nil)

    self.startPosition = {
        x = x,
        y = y,
    }

    self.x = self.startPosition.x
    self.y = self.startPosition.y

    self.margin = 0

    -- Set default spacing
    self.spacing = {
        x = 0,
        y = 0,
    }

    if spacing then
        if type(spacing) == "table" then
            self.spacing.x = spacing.x
            self.spacing.y = spacing.y
        elseif type(spacing) == "number" then
            self.spacing.x, self.spacing.y = tonumber(spacing), tonumber(spacing)
        end
    end


    return self
end

function OverlayGroup:addOverlay(overlay)
    self.overlays = self.overlays or {}
    table.insert(self.overlays, overlay)
    return overlay
end


function OverlayGroup:preRender()
    
end

function OverlayGroup:render()

    
    -- Prevent errors withd defaults
    self.spacing = self.spacing or {}
    self.spacing.x = self.spacing.x or 0
    self.spacing.y = self.spacing.y or 0

    -- Reposition all overlays
    local positionX, positionY = self.x, self.y
    local directionX, directionY = 1, 0

    -- Prevent nil errors with default fallback values
    self.align = self.align or Overlay.ALIGN_HORIZONTAL_LEFT
    self.direction = self.direction or LAYOUT.HORIZONTAL

    -- if self.direction == LAYOUT.HORIZONTAL or self.direction == LAYOUT.HORIZONTAL_RIGHT_ALIGN then
    -- end
    if self.direction == LAYOUT.HORIZONTAL then
        directionX, directionY = 1, 0
    elseif self.direction == LAYOUT.HORIZONTAL_RIGHT_ALIGN then
        directionX, directionY = -1, 0
    elseif self.direction == LAYOUT.VERTICAL or self.direction == LAYOUT.VERTICAL_DOWN then
        -- positionY = 1.0 - positionY -- Invert the Y-position (since th Y-coordinate is inversed)
        directionX, directionY = 0, -1 -- Set the stepping to be "backwards"
    elseif self.direction == LAYOUT.VERTICAL_UP then
        directionX, directionY = 0, 1
    end

    local box = {
        left = positionX,
        top = positionY,
        width = 0,
        height = 0,
    }

    local lastWidth, lastHeight = 0, 0
    -- print("Begin render!")
    for i,overlay in ipairs(self.overlays) do
        if overlay.visible then
            lastWidth = overlay.width
            lastHeight = overlay.height

            if i > 1 then -- If not first item, add spacing between elements
                positionX = positionX + (self.spacing.x * directionX)
                positionY = positionY + (self.spacing.y * directionY)
                box.width = box.width + (self.spacing.x * math.abs(directionX))
                box.height = box.height + (self.spacing.y * math.abs(directionY))
            end

            -- Use offset to handle different alignments
            --TODO: add vertical clamping as well
            local xPositionOffset = 0
            if self.align == Overlay.ALIGN_HORIZONTAL_RIGHT then
                xPositionOffset = -lastWidth
            else
                xPositionOffset = 0
            end
        

            -- print("Render overlay " .. i .. ": ", overlay.overlayId, lastWidth, positionX)

            if self.direction == LAYOUT.HORIZONTAL then
                overlay:setPosition(positionX + xPositionOffset, positionY)
                positionX = positionX + (lastWidth * directionX)
                positionY = positionY + (lastHeight * directionY)
                box.width = box.width + lastWidth
                box.height = math.max( box.height, lastHeight )
            elseif self.direction == LAYOUT.HORIZONTAL_RIGHT_ALIGN or self.direction == LAYOUT.HORIZONTAL_LEFT then
                positionX = positionX + (lastWidth * directionX)
                positionY = positionY + (lastHeight * directionY)
                overlay:setPosition(positionX + xPositionOffset, positionY)
                box.width = box.width + lastWidth
                box.height = math.max( box.height, lastHeight )
            elseif self.direction == LAYOUT.VERTICAL or self.direction == LAYOUT.VERTICAL_DOWN then
                positionX = positionX + (lastWidth * directionX)
                positionY = positionY + (lastHeight * directionY)
                overlay:setPosition(positionX + xPositionOffset, positionY)
                
                box.height = box.height + lastHeight
                box.width = math.max( box.width, lastWidth )
            elseif self.direction == LAYOUT.VERTICAL_UP then
                overlay:setPosition(positionX + xPositionOffset, positionY)
                positionX = positionX + (lastWidth * directionX)
                positionY = positionY + (lastHeight * directionY)
                box.height = box.height + lastHeight
                box.width = math.max( box.width, lastWidth )
            end
        end
    end

    -- Move position to include the width and height of the last overlay
    if self.direction == LAYOUT.HORIZONTAL then
        positionY = positionY + lastHeight
    elseif self.direction == LAYOUT.HORIZONTAL_RIGHT_ALIGN then
        positionY = positionY + lastHeight
    elseif self.direction == LAYOUT.VERTICAL or self.direction == LAYOUT.VERTICAL_DOWN then
        positionX = positionX + lastWidth
    elseif self.direction == LAYOUT.VERTICAL_UP then
        positionX = positionX + lastWidth
    end

    -- Resize and render background (if enabled)
    if self.hasBackground and self.background then
        local bgLeft = box.left
        local bgTop = box.top
        local bgWidth = box.width
        local bgHeight = box.height
        if self.direction == LAYOUT.VERTICAL then
            bgTop = bgTop - bgHeight
        elseif self.direction == LAYOUT.HORIZONTAL_RIGHT_ALIGN or self.direction == LAYOUT.HORIZONTAL_LEFT then
            bgLeft = bgLeft - bgWidth
        end

        self.background:setPosition(bgLeft, bgTop)
        self.background:setDimension(bgWidth, bgHeight)
        self.background:render()
    end

    -- Render all overlays
    for _,overlay in ipairs(self.overlays) do
        overlay:render()
    end

end

local IconOverlay = inherit(g_Overlay)
Renderman.IconOverlay = IconOverlay

function IconOverlay:new(iconFilename, options)
    local settings = { --InheritClass({ -- defaults
        x = 0,
        y = 0,
        width = 0.02,
        height = 0.02,
        filename = iconFilename,
    } --, self)

    if options then
        assert(type(options) == "table")
        for key,value in pairs(options) do
            settings[key] = value
        end
    end

    -- DebugHelper.dumptable("self")


    
    local base = g_Overlay:new(settings.filename, settings.x, settings.y, settings.width, settings.height)

    return base

end


Renderman.OverlayGroup = OverlayGroup
Renderman.PX2U = getScaledUnitFromPixel
Renderman.Overlay = g_Overlay
Renderman.pixel = pixel
Renderman.pixelY = pixelY
Renderman.pixels = pixels

return initlib("Renderman", Renderman)
