local fillTypeByNameCache = {}

g_currentMission.fillTypeManager.getFilltypeByName = function(self, name)
    assert(name, "Parameter 'name' cannot be nil")
    assert(type(name), "Parameter 'name' should be a string")

    if fillTypeByNameCache[name] ~= nil then
        return fillTypeByNameCache[name]
    end

    for key, fillType in pairs(self.fillTypes) do
        
        if fillType.name == nil or type(fillType.name) ~= "string" then
            -- TODO: What can we do?
        else
            if name:upper() == fillType.name:upper() then
                fillTypeByNameCache[name] = {
                    index = fillType.index,
                    title = fillType.title,
                    name = fillType.name
                }
                return fillTypeByNameCache[name]
            end
        end
    end
    return  -- no match
end
