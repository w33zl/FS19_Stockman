local DebugHelper = {}

function logtable(t, maxLevels)
    if setFileLogPrefixTimestamp then setFileLogPrefixTimestamp(false) end

    local print_r_cache = {}

    local function sub_print_r(t, indent)

        if (print_r_cache[tostring(t)]) then
            print(indent .. "*" .. tostring(t))
        else
            print_r_cache[tostring(t)] = true
            if (type(t) == "table") then
                for pos, val in pairs(t) do
                    pos = tostring(pos)

                    if (type(val) == "table") then
                        print(indent .. "[" .. pos .. "] => " .. tostring(t) .. " {")
                        sub_print_r(val, indent .. string.rep(" ", 4))
                        -- sub_print_r(val, indent .. string.rep(".", string.len(pos) + 8))
                        -- print(indent .. string.rep("_", string.len(pos) + 6) .. "}")
                        print(indent .. "}")
                    elseif (type(val) == "string") then
                        print(indent .. "[" .. pos .. '] => "' .. val .. '"')
                    else
                        print(indent .. "[" .. pos .. "] => " .. tostring(val))
                    end
                end
            else
                print(indent .. tostring(t))
            end
        end
    end

    if (type(t) == "table") then
        print(tostring(t) .. " {")
        sub_print_r(t, "  ")
        print("}")
    else
        sub_print_r(t, "  ")
    end

    print()

    if setFileLogPrefixTimestamp then setFileLogPrefixTimestamp(true) end
end

function DebugHelper.dumptable(name, table, maxLevels)

    -- if type(name) == "string" and table == nil then
    --     table = loadstring("return " .. name)
    -- end
    print("DUMP TABLE " .. name)
    pcall(function ()
        logtable(table);
    end);
    
end

function DebugHelper.dumpkeys(name, table)
    if type(name) == "string" and table == nil then
        table = loadstring("return " .. name)()
    end
    print("DUMP KEYS IN TABLE " .. name)
    pcall(function ()
        for k,v in pairs(table) do
            print("> " .. k);
        end
    end);
end

return DebugHelper