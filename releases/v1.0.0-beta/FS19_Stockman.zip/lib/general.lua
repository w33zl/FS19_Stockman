
local General = {}

function General.wait(seconds)
    local elapsed = 0.0
    local start = os.clock()
    while elapsed < seconds do
        elapsed = os.clock() - start
    end
end
if _G.wait == nil then _G.wait = General.wait end

function General.clone(object)
    local newObject = {}
    for key, value in pairs(object) do
        newObject[key] = value
    end
    return newObject
end
if _G.clone == nil then _G.clone = General.clone end


General.merge = function(object1, object2)
    local newObject = {}
    for key, value in pairs(object2) do
        newObject[key] = value
    end
    for key, value in pairs(object1) do
        newObject[key] = value
    end
    return newObject
end
if _G.merge == nil then _G.merge = General.merge end


return General


