--*** GLOBAL: STRING ***

--- Formats a string based on a template
local function string_format_template(templateString, valueTable)
    -- Allow replace_vars{str, vars} syntax as well as replace_vars(str, {vars})
    if not valueTable then
        valueTable = templateString
        templateString = valueTable[1]
    end
    return (string.gsub(templateString, "({([^}]+)})",
        function(whole,i)
            return valueTable[i] or whole
        end))
end

string.formatTemplate = string_format_template
string.tformat = string.formatTemplate -- Shorthand alias
getmetatable("").tformat = string.tformat -- ":self"-syntax alias



local function string_format_number(n) -- credit http://richard.warburton.it
	local left,num,right = string.match(n,'^([^%d]*%d)(%d*)(.-)$')
	return left..(num:reverse():gsub('(%d%d%d)','%1,'):reverse())..right
end

string.formatNumber = string_format_number
string.nformat = string.formatNumber -- Shorthand alias
getmetatable("").tformat = string.tformat -- ":self"-syntax alias

