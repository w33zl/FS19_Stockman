return {
    showSummary = true,
    showIcons = true,
    showAlerts = true,
    uiScale = 1.0,
}