-- local GlobalOverlay = Overlay

local g_currentModDirectory = g_currentModDirectory or ""
local Renderman = require("renderman")
source(g_currentModDirectory .. "husbandryStats.lua")
-- local DebugHelper = loadlib("lib/debughelper.lua")
loadlib "lib/general.lua"

local TEXTS = require("texts")

loadlib "lib/string.lua"
loadlib "modutility"

-- Aliases
local pixel = Renderman.pixel
local pixels = Renderman.pixels
local pixelY = Renderman.pixelY

local stockman = NewMod("Stockman", "1.0", {
    author = "Mikael Levén",
    description = "Stockman gives you an overview of your animal husbandry with alerts and summaries of performance indicators (key statistics).",
})

local FILES = {
    BG = "overlay_bg.dds",
    COW = "cow_outline.dds",
    CHICKEN = "chicken_outline.dds",
    PIG = "pig_outline.dds",
    SHEEP = "sheep_outline.dds",
    HORSE = "horse_outline.dds",
}


stockman.CONFIG = {
    ICONS_X = 1.0 - pixel(20),
    ICONS_Y = (1.0 - pixelY(300)),
    ICON_SIZE_PX = 52,
    ICONS_SPACING = pixel(5),
    MARGIN = pixel(20),
}

stockman.COLORS = {
    ICON_GOOD = COLOR.GOOD,
    ICON_NORMAL = COLOR.WHITE,
    ICON_DIMMED = RGBA(255, 255, 255, 20),
    ICON_WARN = COLOR.WARNING,
    ICON_ERROR = COLOR.CRITICAL,
}

stockman.TEXTSTYLES = {
    NORMAL              = merge( { color = RGB(200, 200, 200) },           FONT.NORMAL),
    SMALL                = merge( { color = RGB(200, 200, 200) },           FONT.SMALL),
    HEADLINE_DISABLE    = merge( { color = RGBA(200, 200, 200, 50) },       FONT.FOCUSED),
    HEADLINE_NORMAL     = merge( { color = RGB(200, 200, 200) },            FONT.FOCUSED),
    ALIGN_RIGHT         = { align = RenderText.ALIGN_RIGHT },
}

local THRESHOLDS = {
    DAYSLEFT_WARNING = 0.8,
    DAYSLEFT_CRITICAL = 0.25,
    ESSENTIALSPERCENT_NOTOPTIMAL = 80,
    ESSENTIALSPERCENT_WARNING = 33,
    ESSENTIALSPERCENT_CRITICAL = 10,
    FOODPERCENT_NOTOPTIMAL = 80,
    FOODPERCENT_WARNING = 25,
    FOODPERCENT_CRITICAL = 10,
    PRODUCTIVITY_NOTOPTIMAL = 95,
    PRODUCTIVITY_WARNING = 75,
    PRODUCTIVITY_CRITICAL = 30,
    CLEANLINESS_NOTOPTIMAL = 85,
    CLEANLINESS_WARNING = 50,
    CLEANLINESS_CRITICAL = 20,
}

local ALERT_TEXT_STYLE = {
    INFO = merge( { color = COLOR.WHITE }, FONT.THIN),
    WARN = merge( { color = COLOR.WARNING }, FONT.THIN),
    ERR = merge( { color = COLOR.CRITICAL }, FONT.THIN),
}

local summaryMaxWidth, summarySecondaryMaxWidth = nil, nil

local defaultSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20) }, stockman.TEXTSTYLES.NORMAL),
    merge({ spacing = pixel(40), align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.NORMAL),
}
local warningSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.WARNING }, stockman.TEXTSTYLES.NORMAL),
    merge({ spacing = pixel(40), color = COLOR.WARNING, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.NORMAL),
}
local criticalSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.CRITICAL }, stockman.TEXTSTYLES.NORMAL),
    merge({ spacing = pixel(40), color = COLOR.CRITICAL, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.NORMAL),
}
local disabledSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.GRAY_80 }, stockman.TEXTSTYLES.NORMAL),
    merge({ spacing = pixel(40), color = COLOR.GRAY_80, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.NORMAL),
}
local secondarySummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20) }, stockman.TEXTSTYLES.SMALL),
    merge({ spacing = pixel(40), align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.SMALL),
}
local secondaryDisabledSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.GRAY }, stockman.TEXTSTYLES.SMALL),
    merge({ spacing = pixel(40), color = COLOR.GRAY, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.SMALL),
}
local secondaryWarningSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.WHITE }, stockman.TEXTSTYLES.SMALL),
    merge({ spacing = pixel(40), color = COLOR.WHITE, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.SMALL),
}
local secondaryCriticalSummaryFormat = {
    summaryMaxWidth,
    summarySecondaryMaxWidth,
    merge({ spacing = pixel(20), color = COLOR.CRITICAL }, stockman.TEXTSTYLES.SMALL),
    merge({ spacing = pixel(40), color = COLOR.CRITICAL, align = RenderText.ALIGN_RIGHT }, stockman.TEXTSTYLES.SMALL),
}

local DISPLAY_MODES = {
    HIDDEN = 1,
    ICONS_ONLY = 2,
    ICONS_OVERVIEW = 4,
    ICONS_ALERTS = 8,
    ICONS_ALERTS_PENINFO = 16,
    OVERVIEW_PEN = 2,
    OVERVIEW_FULL = 4,
}


local function registerActionEventsVehicle()
    do -- ShowOverview
        local wasRegistered, eventShowOverviewName = g_inputBinding:registerActionEvent(InputAction.Stockman_ShowOverview_Vehicle, stockman, stockman.onToggleOverview, false ,true ,false ,true)
        if wasRegistered then
            local showOverview = g_inputBinding.events[eventShowOverviewName]
            showOverview.contextDisplayText = TEXTS.SHORTCUT_OVERVIEW_TOGGLE
            showOverview.displayIsVisible = true;
        else
            print("Warning: failed to register Stockman ShowOverview hotkey for Vehicle")
        end
    end
end

function stockman:updateShortcutTexts()
    --TODO: should update text depending on status, but not working a.t.m.

    -- self.displayMode = self.displayMode or DISPLAY_MODES.ICONS_ALERTS_PENINFO

    -- if self.displayMode == DISPLAY_MODES.HIDDEN then -- Hidden
    --     self.shortcuts.toggleOverlay.contextDisplayText = TEXTS.SHORTCUT_INFOTOGGLE_HIDDEN
    -- elseif self.displayMode == DISPLAY_MODES.ICONS then -- Icons only
    --     self.shortcuts.toggleOverlay.contextDisplayText = TEXTS.SHORTCUT_INFOTOGGLE_ICONS
    -- elseif self.displayMode == DISPLAY_MODES.ICONS_ALERTS then -- Icons and alerts
    --     self.shortcuts.toggleOverlay.contextDisplayText = TEXTS.SHORTCUT_INFOTOGGLE_ICONSALERTS
    -- elseif self.displayMode == DISPLAY_MODES.ICONS_ALERTS_PENINFO then -- All (icons, alerts, peninfo)
    --     self.shortcuts.toggleOverlay.contextDisplayText = TEXTS.SHORTCUT_INFOTOGGLE_ALL
    -- end

    -- if self.overlay.summary.visible == true then
    --     self.shortcuts.showOverview.contextDisplayText = TEXTS.SHORTCUT_OVERVIEW_CLOSE
    -- else
    --     self.shortcuts.showOverview.contextDisplayText = TEXTS.SHORTCUT_OVERVIEW_OPEN
    -- end

    -- -- self.shortcuts.showOverview.displayIsVisible = true;

    local inputRegisterEntry = {}
    inputRegisterEntry.eventId = self.shortcuts.showOverviewName
    g_inputBinding:beginActionEventsModification(Player.INPUT_CONTEXT_NAME)

    local overviewText = "Stockman: Overview"
    if self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_PEN then
        overviewText = TEXTS.SHORTCUT_OVERVIEW_PEN
    elseif self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_FULL then
        overviewText = TEXTS.SHORTCUT_OVERVIEW_FULL
    else
        overviewText = TEXTS.SHORTCUT_OVERVIEW_NONE
    end
    g_inputBinding:setActionEventText(inputRegisterEntry.eventId, overviewText)

    -- if self.overlay.summary.visible then
    --     g_inputBinding:setActionEventText(inputRegisterEntry.eventId, "Stockman: Show overlay [ALWAYS]")
    -- else
    --     g_inputBinding:setActionEventText(inputRegisterEntry.eventId, "Stockman: Show overlay [AUTO]")
    -- end
    g_inputBinding:setActionEventActive(inputRegisterEntry.eventId, true)

    g_inputBinding:setActionEventTextVisibility(inputRegisterEntry.eventId, true)
    g_inputBinding:endActionEventsModification()




end


function stockman:loadMap()
    TEXTS:translate(g_i18n)

    Player.registerActionEvents = Utils.appendedFunction(Player.registerActionEvents, self.registerActionEventsPlayer);
    Player.removeActionEvents = Utils.appendedFunction(Player.removeActionEvents, self.removeActionEventsPlayer);
    Vehicle.registerActionEvents = Utils.appendedFunction(Vehicle.registerActionEvents, self.registerActionEventsPlayer);
    Vehicle.removeActionEvents = Utils.appendedFunction(Vehicle.removeActionEvents, self.removeActionEventsPlayer);

    --addConsoleCommand("smOpen", "Open Stockman UI", "commandOpen", self)

    self.husbandryStats = HusbandryStats:new(g_currentMission.husbandries)

    self.gfxDir = self.dir .. "resources/"
    self.displayMode = DISPLAY_MODES.ICONS_ALERTS

	-- GUI
    self.gui = {};
    self.gui.main = StockmanGui:new();
    self.gui.main.handle = "StockmanGui"
    self.gui.main.callback = self.guiUpdate
    g_gui:loadGui(self.dir .. "gui/stockman_gui.xml", self.gui.main.handle, self.gui.main);

    self.gui.dir = self.dir
    self.gui.resources = self.dir .. "resources/"

    local iconSettings = {
        width = pixels(stockman.CONFIG.ICON_SIZE_PX).x,
        height = pixels(stockman.CONFIG.ICON_SIZE_PX).y,
        opacity = 1.0,
    }

    self.overlay = {}

    self.overlay.alerts = Renderman.TextOverlay:new({
        background = self.gui.resources .. "bg_fade.dds",
        color = COLOR.BLACK_40,
        x = iconSettings.width + pixel(40),
        y = 1 - self.CONFIG.ICONS_Y,
        lineHeight = 1.5,
        padding = pixels(5),
        horizontalAlign = Overlay.ALIGN_HORIZONTAL_RIGHT,
        verticalAlign = Overlay.ALIGN_VERTICAL_TOP,
        shadows = true,
    });

    self.overlay.summary = Renderman.TextOverlay:new({
        background = self.gui.resources .. "overlay_bg.dds",
        color = COLOR.BLACK_BG,
        x = self.overlay.alerts.x,
        y = pixelY(60),
        horizontalAlign = Overlay.ALIGN_HORIZONTAL_RIGHT,
        verticalAlign = Overlay.ALIGN_VERTICAL_MIDDLE,
        tableMode = true,
        shadows = true,
    });

    self.overlay.activePen = Renderman.TextOverlay:new({
        background = self.gui.resources .. "overlay_bg.dds",
        color = COLOR.BLACK_BG,
        x = pixel(20),
        y = 0,
        horizontalAlign = Overlay.ALIGN_HORIZONTAL_RIGHT,
        verticalAlign = Overlay.ALIGN_VERTICAL_MIDDLE,
        tableMode = true,
        shadows = true,
    });

    self.overlay.summaryDisplayMode = DISPLAY_MODES.OVERVIEW_PEN

    --TODO: Maybe move to update-method and refactor to add support for multple pens (per animal type)?
    self.overlay.icons = {} do local icons = self.overlay.icons
        icons.group     = Renderman.OverlayGroup:new(self.gfxDir .. FILES.BG, self.CONFIG.ICONS_X, self.CONFIG.ICONS_Y, self.CONFIG.ICONS_SPACING)
        icons.group.background:setColor(0, 0, 0, 0.0)
        icons.group.direction = LAYOUT.VERTICAL
        icons.group.align = Overlay.ALIGN_HORIZONTAL_RIGHT

        icons.cow       = icons.group:addOverlay( Renderman.IconOverlay:new(self.gfxDir .. FILES.COW,      iconSettings) )
        icons.pig       = icons.group:addOverlay( Renderman.IconOverlay:new(self.gfxDir .. FILES.PIG,      iconSettings) )
        icons.sheep     = icons.group:addOverlay( Renderman.IconOverlay:new(self.gfxDir .. FILES.SHEEP,    iconSettings) )
        icons.chicken   = icons.group:addOverlay( Renderman.IconOverlay:new(self.gfxDir .. FILES.CHICKEN,  iconSettings) )
        icons.horse     = icons.group:addOverlay( Renderman.IconOverlay:new(self.gfxDir .. FILES.HORSE,    iconSettings) )
    end

    self:loaded()
end

function stockman:guiUpdate(canceled)
    print("Update from GUI " .. tostring(canceled))
end

function stockman:commandOpen(...)
    self:onToggleMenu()
end

function stockman:onToggleMenu()
    if self.gui.main.isOpen then
		self.gui.main:onClickBack()
	elseif g_gui.currentGui == nil then
		g_gui:showGui(self.gui.main.handle)
	end;
end

function stockman:onToggleOverlay()
    --todo: change display mode

    self.displayMode = self.displayMode or DISPLAY_MODES.HIDDEN -- Default/fallback to "hidden" to get our perefed default when we rotate

    print("Toggle overlay, is: " .. tostring(self.displayMode))

    if self.displayMode == DISPLAY_MODES.HIDDEN then -- Go from Hidden to "Show all"
        self.displayMode = DISPLAY_MODES.ICONS_ALERTS_PENINFO

    -- elseif self.displayMode == DISPLAY_MODES.ICONS_ALERTS_PENINFO then -- Go from "Show all" to Icons+alerts
    --     self.displayMode = DISPLAY_MODES.ICONS_ALERTS

    -- elseif self.displayMode == DISPLAY_MODES.ICONS_ALERTS then -- Go from Icons + alerts to Icons only
    --     self.displayMode = DISPLAY_MODES.ICONS_ONLY

    -- elseif self.displayMode == DISPLAY_MODES.ICONS_ONLY then -- Go from Icons only to Hidden
    --     self.displayMode = DISPLAY_MODES.HIDDEN

    else
        self.displayMode = DISPLAY_MODES.HIDDEN
    end
    -- -- Toggle visibility
    -- self.overlay.summary.visible = not (true and self.overlay.summary.visible)

    -- if self.overlay.summary.visible then
    --     self:updateGui() -- Force re-update of the UI
    -- end

    -- -- print("Overlay changed to: " .. tostring(self.overlay.summary.visible))

    self:updateShortcutTexts()


    if self.displayMode ~= DISPLAY_MODES.HIDDEN then -- Go from Hidden to "Show all"
        self:updateGui() -- Force re-update of the UI
    end
end

function stockman:onToggleOverview()

    print("Toggle overview")
    -- Toggle visibility
    -- self.overlay.summary.visible = not (true and self.overlay.summary.visible)

    self.overlay.summaryDisplayMode = self.overlay.summaryDisplayMode or DISPLAY_MODES.HIDDEN

    if self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_PEN then
        self.overlay.summaryDisplayMode = DISPLAY_MODES.OVERVIEW_FULL
    elseif self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_FULL then
        self.overlay.summaryDisplayMode = DISPLAY_MODES.HIDDEN
    else
        self.overlay.summaryDisplayMode = DISPLAY_MODES.OVERVIEW_PEN
    end

    self:updateShortcutTexts()

    -- if self.overlay.summary.visible then
    if self.overlay.summaryDisplayMode ~= DISPLAY_MODES.HIDDEN then
        self:updateGui() -- Force re-update of the UI
    end





    -- g_inputBinding:removeActionEventsByActionName(InputAction.MENU_PAGE_PREV)
    -- local valid, eventId = g_inputBinding:registerActionEvent(InputAction.MENU_PAGE_NEXT, dialog, SeasonsWorkshop.inj_directSellDialog_switchVehicleEvent, false, true, false, true, 1)
    -- dialog.seasons_tabbingEventIdNext = eventId



    do -- ShowOverview
        -- g_inputBinding:removeActionEventsByActionName(InputAction.Stockman_ShowOverview)
        -- -- stockman.stateObject = stockman.stateObject or {}
        -- local wasRegistered, eventShowOverviewName = g_inputBinding:registerActionEvent(InputAction.Stockman_ShowOverview, stockman, stockman.onToggleOverview ,false, true ,false ,true)
        -- -- print("Regit: " .. tostring(eventShowOverviewName))
        -- -- DebugHelper.dumpkeys("eventShowOverviewName", eventShowOverviewName)
        -- if wasRegistered then
        --     self.shortcuts.showOverview = g_inputBinding.events[eventShowOverviewName]
        --     self.shortcuts.showOverviewName = eventShowOverviewName
        --     -- table.insert(fastnight.eventName, eventName);
        --     -- g_inputBinding.events[eventShowOverlayName].contextDisplayText = "Stockman: TEstar"'



            -- if self.overlay.summary.visible then
            --     self.shortcuts.showOverview.contextDisplayText = TEXTS.SHORTCUT_OVERVIEW_TOGGLE .. " XXX"
            -- else
            --     self.shortcuts.showOverview.contextDisplayText = TEXTS.SHORTCUT_OVERVIEW_TOGGLE .. " YYY"
            -- end
            -- g_inputBinding:setActionEventText(self.shortcuts.showOverviewName, self.shortcuts.showOverview.contextDisplayText)
            -- g_inputBinding:setActionEventActive(self.shortcuts.showOverviewName, true)


        --     -- DebugHelper.dumptable("self.shortcuts.showOverview", self.shortcuts.showOverview)

        --     self.shortcuts.showOverview.displayIsVisible = true;
        -- else
        --     print("Warning: failed to register Stockman ShowOverview hotkey")
        -- end
    end



end


local WARNING_LEVEL = {
    NONE = 0,
    INFO = 1,
    WARNING = 2,
    CRITICAL = 3
}


local SummaryWriter = {}

function SummaryWriter:writeColumns(...)
    for _, target in ipairs(self.targets) do
        target:writeColumns(...)
    end
end

function SummaryWriter:write(...)
    for _, target in ipairs(self.targets) do
        target:write(...)
    end
end

function SummaryWriter:new(...)
    local self = setmetatable({}, { __index = self } )
    self.targets = {}
    for _, target in ipairs({...}) do
        table.insert( self.targets, target )
    end
    return self
end

local function updateOverlaysForAnimal(self, icon, stats)
    icon.visible = (stats ~= nil) -- Set v

    if icon.visible == false then
        return
    end


    local alerts = self.overlay.alerts
    local summary
    local animalsName = TEXTS[stats.animalType:upper()]

    if self.nearbyPen and self.nearbyPen.husbandryID == stats.husbandryID then
        summary = SummaryWriter:new(self.overlay.summary, self.overlay.activePen)
    else
        summary = self.overlay.summary
    end

    do -- Summary overlay > headline per animal
        local animalHeadline = animalsName
        local headlineStyle = stockman.TEXTSTYLES.HEADLINE_DISABLE
        if stats.animalCount > 0 then
            animalHeadline = animalHeadline .. " (" .. stats.animalCount .. ")"
            headlineStyle = stockman.TEXTSTYLES.HEADLINE_NORMAL
        end
        summary:writeColumns(animalHeadline, "", summaryMaxWidth, nil, headlineStyle)
    end

    if stats:hasAnimals() then
        icon:setColor(unpack(stockman.COLORS.ICON_NORMAL))

        local iconWarnLevel = WARNING_LEVEL.NONE


        local function formatFillLevel(item)
            return
                "(" .. string.formatNumber(math.floor(item.fillLevel)) .. " l)   " ..
                -- "/" .. math.floor(item.capacity) .."L) " ..
                item.percentageFillLevel .. "%"
        end
        local function formatOutputFillLevel(item)
            local woolFillType = g_currentMission.fillTypeManager:getFillTypeByName("WOOL") --TODO: Should retrieve using built-in "find by name" instead of custom one
            -- if woolFillType and woolFillType.title == item.title then
            --     return string.formatNumber(math.floor(item.weight)) .." kg" --TODO: replace to use kg again?
            -- else
                return string.formatNumber(math.floor(item.fillLevel)) .." l"
            -- end
        end
        local function formatFoodGroupFillLevel(foodGroup)
            local foodLevels = ""
            for _, food in pairs(foodGroup.foods) do
                if foodLevels ~= "" then
                    foodLevels = foodLevels .. "/"
                end
                foodLevels = foodLevels .. string.formatNumber(math.floor(food.fillLevel))
            end
            local percentText = foodGroup.percentageFillLevel .. "%"
            percentText = string.rep( " ", 12 - string.len(percentText) ) .. percentText
            return "(" .. foodLevels .. " l)" .. percentText
            -- return foodLevels --.. " of " .. math.floor(foodGroup.capacity)
        end
        local function formatFoodGroupTitle(foodGroup)
            local foodTitles = ""
            for _, food in pairs(foodGroup.foods) do
                -- if food.title ~= foodGroup.title then
                    if foodTitles ~= "" then
                        foodTitles = foodTitles .. ", "
                    end
                    foodTitles = foodTitles .. food.title
                -- end
            end
            --TODO: fix bug with removing grass when should show both grass and hay
            if foodTitles.title == foodGroup.title then
                foodTitles = "" -- No need to show only one food title when the food group has the exact same name
            elseif foodTitles ~= "" then
                foodTitles = " (" .. foodTitles .. ")"
            end

            local suffix = ""
            if foodGroup.productionWeight == 1.0 then suffix = " ++" end
            if foodGroup.productionWeight < 0.5 then suffix = " -" end

            return "-" .. foodGroup.title .. foodTitles .. suffix
        end
        local function formatWeight(weight)
            --TODO: add support for kg, tons
        end
        local function camelCaseWord(word)
            return string.sub(word:upper(), 1, 1) .. string.sub(word:lower(), 2)
        end
        local function addCasingVariantsToTemplateTexts(values)

            for key, value in pairs(values) do
                if type(value) ~= "string" then
                    value = tostring(value)
                end
                values[key:lower()] = value:lower()
                values[key:upper()] = value:upper()
                values[camelCaseWord(key)] = camelCaseWord(value)
            end
            return values
        end
        local function showAlert(message, values, level)
            values.animal = animalsName
            -- values.Animal = animalsName
            values = addCasingVariantsToTemplateTexts(values)
            level = level or WARNING_LEVEL.INFO
            local textStyle = ALERT_TEXT_STYLE.INFO
            if level == WARNING_LEVEL.CRITICAL then
                textStyle = ALERT_TEXT_STYLE.ERR
            elseif level == WARNING_LEVEL.WARNING then
                textStyle = ALERT_TEXT_STYLE.WARN
            elseif level == WARNING_LEVEL.INFO then
                -- print("Alert INFO")
                textStyle = ALERT_TEXT_STYLE.INFO
            end
            alerts:write(string.tformat(message, values), nil, textStyle)
            -- alerts:write("[" .. animalsName:upper() .. "] " .. string.tformat(message, values), nil, textStyle)
        end

        local function formatDays(days)
            local daysText = ""
            local fullDays = math.floor(days)
            local diff = days - fullDays

            if diff == 0 then
                daysText = tostring(fullDays)
            elseif diff > 0.5 then
                daysText = tostring(fullDays + 1)
            elseif diff <= 0.5 then
                daysText = tostring(fullDays + 0.5)
            end

            return daysText .. " day(s)"
        end


        --* CONDITION

        if stats.condition and stats.condition.productivity then -- PRODUCTIVITY
            local productivitySummaryFormat = defaultSummaryFormat
            local statValues = { what = TEXTS.PRODUCTIVITY, percent = stats.condition.productivity }
            if stats.condition.productivity < THRESHOLDS.PRODUCTIVITY_CRITICAL then
                productivitySummaryFormat = criticalSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                showAlert(
                    TEXTS.ALERT_CONDITION_CRITICAL,
                    statValues,
                    WARNING_LEVEL.CRITICAL)
            elseif stats.condition.productivity < THRESHOLDS.PRODUCTIVITY_WARNING then
                productivitySummaryFormat = warningSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                showAlert(
                    TEXTS.ALERT_CONDITION_WARNING,
                    statValues,
                    WARNING_LEVEL.WARNING)
            elseif stats.condition.productivity < THRESHOLDS.PRODUCTIVITY_NOTOPTIMAL then
                -- productivitySummaryFormat = defaultSummaryFormat
                -- iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                showAlert(
                    TEXTS.ALERT_CONDITION_INFO,
                    statValues,
                    WARNING_LEVEL.INFO)
            end
            summary:writeColumns(TEXTS.PRODUCTIVITY, stats.condition.productivity .. "%", unpack(productivitySummaryFormat))
        end
        if stats.condition and stats.condition.cleanliness then -- CLEANLINESS
            --TODO: add alert
            --TODO: add warning color
            local cleanlinessSummaryFormat = defaultSummaryFormat
            local cleanlinessFormatVariables = { what = TEXTS.CLEANLINESS, percent = stats.condition.cleanliness.cleanlinessFactor }

            if stats.condition.cleanliness.cleanlinessFactor < THRESHOLDS.CLEANLINESS_CRITICAL then
                cleanlinessSummaryFormat = criticalSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                showAlert(
                    TEXTS.ALERT_CONDITION_CRITICAL,
                    cleanlinessFormatVariables,
                    WARNING_LEVEL.CRITICAL)
            elseif stats.condition.cleanliness.cleanlinessFactor < THRESHOLDS.CLEANLINESS_WARNING then
                cleanlinessSummaryFormat = warningSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                showAlert(
                    TEXTS.ALERT_CONDITION_WARNING,
                    cleanlinessFormatVariables,
                    WARNING_LEVEL.WARNING)
            end
            summary:writeColumns(TEXTS.CLEANLINESS, stats.condition.cleanliness.cleanlinessFactor .. "%", unpack(cleanlinessSummaryFormat))
        end

        -- ESSENTIALS
        for _, essential in pairs(stats.essentials) do
            if essential then
                -- print("[" .. stats.animalType:upper() .. "] ESSENTIAL " .. essential.title .. " DAYS: " .. type(essential.estimatedDaysLeft))
                local essentialFormat = defaultSummaryFormat
                local essentialFormatVariables = { what = essential.title, percent = essential.percentageFillLevel, days = formatDays(essential.estimatedDaysLeft) }
                if essential.percentageFillLevel == 0 then
                    if essential == stats.essentials.straw then
                        essentialFormat = disabledSummaryFormat
                    else
                        essentialFormat = criticalSummaryFormat
                        iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                        showAlert(TEXTS.ALERT_EMPTY_CRITICAL, essentialFormatVariables, WARNING_LEVEL.CRITICAL)
                    end
                elseif essential.estimatedDaysLeft < THRESHOLDS.DAYSLEFT_CRITICAL then
                    --TODO: add alert
                    showAlert(TEXTS.ALERT_DAYSLEFT_CRITICAL, essentialFormatVariables, WARNING_LEVEL.CRITICAL)
                    essentialFormat = criticalSummaryFormat
                    iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                    -- print("Alert essential CRIT: " .. animalsName ..  essential.title)
                elseif essential.estimatedDaysLeft < THRESHOLDS.DAYSLEFT_WARNING then
                    --TODO: add alert
                    showAlert(TEXTS.ALERT_DAYSLEFT_WARNING, essentialFormatVariables, WARNING_LEVEL.WARNING)
                    essentialFormat = warningSummaryFormat
                    iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                    -- print("Alert essential WRN: " .. animalsName ..  essential.title)
                elseif essential.percentageFillLevel <= THRESHOLDS.ESSENTIALSPERCENT_WARNING then
                    --TODO: add alert
                    essentialFormat = warningSummaryFormat
                    iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                    showAlert(TEXTS.ALERT_LOWLEVEL_WARNING, essentialFormatVariables, WARNING_LEVEL.WARNING)
                    -- print("Alert essential LVL WRN: " .. animalsName ..  essential.title)
                end
                summary:writeColumns(essential.title, formatFillLevel(essential), unpack(essentialFormat))
            end
        end

        do
            local foodPercentage = math.floor( (stats.food.totalAmountOfFood / stats.food.totalFoodCapacity) * 100)
            local foodFormat = defaultSummaryFormat
            local foodFormatVariables = { what = TEXTS.FOOD, percent = foodPercentage, days = formatDays(stats.food.estimatedDaysLeft) }

            if foodPercentage == 0 then
                foodFormat = criticalSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                --TODO: add alert
                showAlert(TEXTS.ALERT_EMPTY_CRITICAL, foodFormatVariables, WARNING_LEVEL.CRITICAL)
            elseif stats.food.estimatedDaysLeft < THRESHOLDS.DAYSLEFT_CRITICAL then
                foodFormat = criticalSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.CRITICAL )
                --TODO: add alert
                showAlert(TEXTS.ALERT_DAYSLEFT_CRITICAL, foodFormatVariables, WARNING_LEVEL.CRITICAL)
            elseif stats.food.estimatedDaysLeft < THRESHOLDS.DAYSLEFT_WARNING then
                foodFormat = warningSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                showAlert(TEXTS.ALERT_DAYSLEFT_WARNING, foodFormatVariables, WARNING_LEVEL.WARNING)
                --TODO: add alert
            elseif foodPercentage < THRESHOLDS.FOODPERCENT_WARNING then
                foodFormat = warningSummaryFormat
                iconWarnLevel = math.max( iconWarnLevel, WARNING_LEVEL.WARNING )
                --TODO: add alert
                showAlert(TEXTS.ALERT_LOWLEVEL_WARNING, foodFormatVariables, WARNING_LEVEL.WARNING)
            end
            summary:writeColumns(TEXTS.FOOD, foodPercentage .. "%", unpack(foodFormat))

            for _, foodGroup in pairs(stats.food.foodGroups) do
                if foodGroup then
                    local foodGroupFormat = secondarySummaryFormat
                    -- Different warning levels for foodgroups: 0% = disabled, <50% = warnign, no critical (because there could be other food present)
                    if foodGroup.percentageFillLevel == 0 then
                        foodGroupFormat = secondaryDisabledSummaryFormat
                    -- elseif foodGroup.percentageFillLevel < THRESHOLDS.FOODPERCENT_CRITICAL then
                    --     -- --TODO: add alert?
                    --     -- alerts:write("[" .. stats.animalType:upper() .. "] Your farm is running low on " .. foodGroup.title, nil, ALERT_TEXT_STYLE.WARN)
                    --     foodGroupFormat = secondaryCriticalSummaryFormat
                    elseif foodGroup.percentageFillLevel < THRESHOLDS.FOODPERCENT_WARNING then
                        -- --TODO: add alert?
                        -- alerts:write("[" .. stats.animalType:upper() .. "] Your farm is running low on " .. foodGroup.title, nil, ALERT_TEXT_STYLE.WARN)
                        foodGroupFormat = secondaryWarningSummaryFormat
                    end
                    summary:writeColumns(formatFoodGroupTitle(foodGroup), formatFoodGroupFillLevel(foodGroup), unpack(foodGroupFormat))
                end
            end
        end

        -- Animal produce (output)
        for _, output in pairs(stats.output) do
            if output then
                if output.percentageFillLevel >= 90 then
                    --TODO: add alert?
                end
                summary:writeColumns(output.title, formatOutputFillLevel(output), unpack(defaultSummaryFormat))
            end
        end

        if iconWarnLevel == WARNING_LEVEL.WARNING then
            icon:setColor(unpack(stockman.COLORS.ICON_WARN))
        elseif iconWarnLevel == WARNING_LEVEL.CRITICAL then
            icon:setColor(unpack(stockman.COLORS.ICON_ERROR))
        end
    else
        icon:setColor(unpack(stockman.COLORS.ICON_DIMMED))
    end

    summary:write("", nil, { padChar = "-" })

end


function stockman:updateGui()
    --TODO: May need refactor to support multiple pens per animal type?
    local stats = self.husbandryStats.animals
    local icons = self.overlay.icons
    self.overlay.summary:reset()
    self.overlay.activePen:reset()
    self.overlay.alerts:reset()
    updateOverlaysForAnimal(self, icons.cow, stats.cow)
    updateOverlaysForAnimal(self, icons.pig, stats.pig)
    updateOverlaysForAnimal(self, icons.sheep, stats.sheep)
    updateOverlaysForAnimal(self, icons.chicken, stats.chicken)
    updateOverlaysForAnimal(self, icons.horse, stats.horse)
end

function stockman:isPlayerCloseToPen(animalPen)

    --TODO: Maybe add suppport to select the -closest- pen, not just the first pen within range?

    if g_currentMission.player == nil and g_currentMission.controlledVehicle == nil then
        return
    end

    local function getPlayerOrVehiclePosition()
        if g_currentMission.controlledVehicle ~= nil then
            if g_currentMission.controlledVehicle.steeringAxleNode ~= nil then
                return getWorldTranslation(g_currentMission.controlledVehicle.steeringAxleNode)
            end
        else
            return g_currentMission.player:getPositionData()
        end
    end

    local x_pos_player, y_pos_player, z_pos_player = getPlayerOrVehiclePosition()

    if x_pos_player == nil or z_pos_player == nil then
        return
    end

    local radius = 33.0 -- 24.0 -- ca. distance in meters

    local x_positionHotspot = 0
    local z_positionHotspot = 0

        local hotspot = animalPen.mapHotspots[1]
        if hotspot ~= nil then
            x_positionHotspot = hotspot.xMapPos
            z_positionHotspot = hotspot.zMapPos

            local distanceBetweenPlayerAndBuilding = math.sqrt(math.pow((x_pos_player - x_positionHotspot), 2) + math.pow((z_pos_player - z_positionHotspot), 2)) -- Algoritm from AnimalsHUD

            if distanceBetweenPlayerAndBuilding < radius then
                return animalPen
            end
        end
end


function stockman:update()
    ModUtility.throttleExecution(self, 0.25, function()
        self.nearbyPen = nil
        for _, animalPen in pairs(self.husbandryStats.animals) do
            if self:isPlayerCloseToPen(animalPen) then
                self.nearbyPen = animalPen
                return
            end
        end
    end);

    if self.husbandryStats:update() then
        self:updateGui()
    end
end

function stockman:draw()

    -- Only render when no other GUI is open
    if g_gui.currentGuiName ~= "InGameMenu" then --if g_gui.currentGui == nil then
        -- If "GUI block"-flag is set we should force update of the UI and reset the flag
        if self.guiBlock then
            print("Gui was blocked")
            self:updateGui()
            self.guiBlock = false
        end

        self.displayMode = self.displayMode or DISPLAY_MODES.ICONS_ALERTS

        --TODO: dummy, show overly when nearby pen, should show only one pen
        -- if self.nearbyPen ~= nil then
        --     self.overlay.activePen:render()
        -- else
        --     self.overlay.summary:render()
        -- end

        if self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_PEN then
            self.overlay.activePen:render()
        elseif self.overlay.summaryDisplayMode == DISPLAY_MODES.OVERVIEW_FULL then
            self.overlay.summary:render()
        end

        -- if self.overlay.summary.visible then
        -- -- if self.displayMode ~= DISPLAY_MODES.ICONS_OVERVIEW then
        --     self.overlay.summary:render()
        -- end

        if self.displayMode == DISPLAY_MODES.ICONS_ALERTS or self.displayMode == DISPLAY_MODES.ICONS_ALERTS_PENINFO then -- Always display icons as long as we should not hide all overlays
            self.overlay.alerts:render()
        end

        if self.displayMode ~= DISPLAY_MODES.HIDDEN then -- Always display icons (except when all overlays should be hidden)
            self.overlay.icons.group:render()
        end
    else
        self.guiBlock = true -- set flag to remember we have blocked rendering due to another GUI being displayed
    end
end



---* Register actions for Player
---@param self table Player
function stockman.registerActionEventsPlayer()
    local self = stockman

    self.shortcuts = self.shortcuts or {}

    -- local evenOpenGuiID, eventOpenGuiName = g_inputBinding:registerActionEvent(InputAction.Stockman_OpenUI, stockman, stockman.onToggleMenu ,false ,true ,false ,true)

    -- if evenOpenGuiID then
    --     self.shortcuts.openUI = g_inputBinding.events[eventOpenGuiName]
    --     g_inputBinding.events[eventOpenGuiName].displayIsVisible = true;
    -- else
    --     print("Warning: failed to register Stockman GUI hotkey")
    -- end


    do -- ShowOverview
        local wasRegistered, eventShowOverviewName = g_inputBinding:registerActionEvent(InputAction.Stockman_ShowOverview, stockman, stockman.onToggleOverview ,false, true ,false ,true)
        if wasRegistered then
            self.shortcuts.showOverview = g_inputBinding.events[eventShowOverviewName]
            self.shortcuts.showOverviewName = eventShowOverviewName
            self.shortcuts.showOverview.displayIsVisible = true;
        else
            print("Warning: failed to register Stockman ShowOverview hotkey")
        end
    end

    -- local eventToggleOverlaysID, eventToggleOverlaysName = g_inputBinding:registerActionEvent(InputAction.Stockman_ToggleOverlay, stockman, stockman.onToggleOverlay, false ,true ,false ,true)
    -- if eventToggleOverlaysID then
    --     self.shortcuts.toggleOverlay = g_inputBinding.events[eventToggleOverlaysName]
    --     self.shortcuts.toggleOverlay.contextDisplayText = TEXTS.SHORTCUT_OVERLAYS_TOGGLE
    --     self.shortcuts.toggleOverlay.displayIsVisible = true;
    -- else
    --     print("Warning: failed to register Stockman Toggle Overlays hotkey")
    -- end

    self:updateShortcutTexts()

    -- local valid, eventId = g_inputBinding:registerActionEvent(InputAction.MENU_PAGE_NEXT, dialog, SeasonsWorkshop.inj_directSellDialog_switchVehicleEvent, false, true, false, true, 1)

    -- local _, eventId = self.inputManager:registerActionEvent(InputAction.SEASONS_SHOW_MENU, self, self.onToggleMenu, false, true, false, true)
    -- self.inputManager:setActionEventTextVisibility(eventId, true)
    -- g_inputBinding:setActionEventTextVisibility(actionEventIdToggle, true)
    -- g_inputBinding:setActionEventTextPriority(actionEventIdToggle, GS_PRIO_NORMAL)
    -- g_inputBinding:setActionEventText(actionEventIdToggle, g_i18n:getText("action_toggle_plant_distance"):format(self.spec_treePlanter.minDistance))

end

function stockman:removeActionEventsPlayer()
    
end


