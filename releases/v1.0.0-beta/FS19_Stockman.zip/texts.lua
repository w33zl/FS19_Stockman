local TEXTS = {

    CHICKEN = { "helpTitle_25", "Chickens" },
    COW = { "helpTitle_21", "Cows" },
    PIG = { "helpTitle_20", "Pigs" },
    HORSE = { "helpTitle_19_01", "Horses" },
    SHEEP = { "helpTitle_24", "Sheep" },
    CLEANLINESS = { "statistic_cleanliness", "Cleanliness" },
    PRODUCTIVITY = { "statistic_productivity", "Productivity" },
    ALERT_EMPTY_CRITICAL = { "stockman_alert_empty_critical", "IMPORTANT! Your {ANIMAL} has no {WHAT}" },
    ALERT_LOWLEVEL_WARNING = { "stockman_alert_lowlevel_warning", "Your {ANIMAL} is running low on {WHAT} ({PERCENT}%)" },
    ALERT_LOWLEVEL_CRITICAL = { "stockman_alert_lowlevel_critical", "Your {ANIMAL} is running critically low on {WHAT} ({PERCENT}%)" },
    ALERT_DAYSLEFT_WARNING = { "stockman_alert_daysleft_warning", "The {WHAT} for your {ANIMAL} will last less than a day" },
    ALERT_DAYSLEFT_CRITICAL = { "stockman_alert_daysleft_critical", "Your {ANIMAL} will run out of {WHAT} within a couple of hours" },
    ALERT_CONDITION_INFO = { "stockman_alert_condition_info", "The {WHAT} for your {ANIMAL} could be better" },
    ALERT_CONDITION_WARNING = { "stockman_alert_condition_warning", "The {WHAT} for your {ANIMAL} is low" },
    ALERT_CONDITION_CRITICAL = { "stockman_alert_condition_critical", "The {WHAT} for your {ANIMAL} is alarmingly low" },

    SHORTCUT_OVERVIEW_PEN = { "stockman_shortcut_overview_pen", "Stockman: Show HUD [Nearby pen]" },
    SHORTCUT_OVERVIEW_FULL = { "stockman_shortcut_overview_full", "Stockman: Show HUD [Overview]" },
    SHORTCUT_OVERVIEW_NONE = { "stockman_shortcut_overview_hidden", "Stockman: Show HUD [None]" },

    SHORTCUT_OVERLAYS_TOGGLE = { "stockman_shortcut_overlay_toggle", "Stockman: Show/hide icons & alerts" },
    SHORTCUT_INFOTOGGLE_HIDDEN = { "stockman_shortcut_overlay_hidden", "Stockman: Hide all (toggle)" },
    SHORTCUT_INFOTOGGLE_ICONS = { "stockman_shortcut_overlay_icons", "Stockman: Icons only (toggle)" },
    SHORTCUT_INFOTOGGLE_ICONSALERTS = { "stockman_shortcut_overlay_iconsalerts", "Stockman: Icons and alerts (toggle)" },
    SHORTCUT_INFOTOGGLE_ALL = { "stockman_shortcut_overlay_all", "Stockman: Show all (toggle)" },

    GRASS = { "fillType_grass", "Grass" },
    OAT = { "fillType_oat", "OAT" },
    WHEAT = { "fillType_wheat", "Wheat" },
    SUGARBEET = { "fillType_sugarBeet", "Sugarbeet" },
    POTATO = { "fillType_potato", "Potato" },
    BARLEY = { "fillType_barley", "Barley" },
    SOYBEAN = { "fillType_soybean", "Soybean" },
    FORAGE = { "fillType_forage", "Forage" },
    TMR = { "fillType_forage", "Total Mixed Ration" },
    TMR_SHORT = { "fillType_tmr", "TMR" },
    STRAW = { "fillType_straw", "Straw" },
    SILAGE = { "fillType_silage", "Silage" },
    HAY = { "fillType_dryGrass", "Hay" },
    DRYGRASS = { "fillType_dryGrass", "Drygrass" },
    MAIZE = { "fillType_maize", "Maize" },
    CANOLA = { "fillType_canola", "Canola" }, -- Raps
    WATER = { "fillType_water", "Water" },
    SUNFLOWER = { "fillType_sunflower", "Sunflower" },

    FOOD = { "ui_animalFood", "Food" },
    PIGFOOD = { "fillType_pigFood", "Pig Food" },
    PIGFOOD_BASE = { "fillType_pigFoodBase", "Pig Food (Base)" },
    PIGFOOD_EARTH = { "fillType_pigFoodEarth", "Pig Food (Earth)" },
    PIGFOOD_GRAIN = { "fillType_pigFoodGrain", "Pig Food (Grain)" },
    PIGFOOD_PROTEIN = { "fillType_pigFoodProtein", "Pig Food (Protein)" },

--     <e k="helpTitle_33" v="Grass &amp; Hay"/>
-- <e k="helpTitle_34" v="Straw &amp; Chaff"/>
-- <e k="helpTitle_35" v="Silage &amp; TMR"/>
-- <e k="helpTitle_36" v="Fertilizers"/>
-- <e k="helpTitle_36_01" v="Lime &amp; Herbicide"/>
-- <e k="helpTitle_37" v="Logs &amp; Wood Chips"/>
-- <e k="helpTitle_38" v="Milk &amp; Wool"/>
-- <e k="helpTitle_39" v="Pigs &amp; Chickens"/>


}

TEXTS.translate = function(self, i18n)
    local function getText(raw)
        local key, fallback = unpack(raw)
        fallback = fallback or i18n:getText(key) --TODO: A quickfix to call getText to get fail message
        return i18n.texts[key] or fallback
    end
    for key, value in pairs(self) do
        if type(value) == "table" then
            self[key] = getText(value)
        end
    end
    return self
end

return initlib("TEXTS", TEXTS)
